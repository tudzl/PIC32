/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project, interrupt handler
    callback functions and Temperature conversion function. The "main"
    function calls the "SYS_Initialize" function to initialize all peripherals
    utilized in this project, calls the different interrupt handler callback
    initialiaztions and the "main" function have the application code to
    toggles an LED on a timeout basis and to print the LED toggling rate
    (or current temperature value if a I/01 Xplained Pro Extension Kit board
    is connected) on the serial terminal.
 *******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
 * Copyright (C) 2022 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *******************************************************************************/
//DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
//PIC32 CM LE00  SPI OLED test program!
//Pinout:
//SPI_CS: PAD2  pin97 PB00
//SPI_SCK: PAD1 pin99  PB02
//SPI_SDO: PAD0 pin100  PB03
//SPI_SDI: PAD3 pin98  PB01


//V1.41  added inversion function, works!!!!
//V1.4  pixel drawing is working!!!!
//V1.31 Black and white is working! draw line not working! SPI driver need optimization! block mode ? or Interrupt mode now?
//V1.3  optimized JDI memory LCD driver, need test!
//V1.21 optimized PB00 SPI_CS pin output

//demo code modified to test Sercom5 SPI OLED driver!
#include <stdio.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <string.h>
#include <xc.h>
#include "definitions.h"                // SYS function prototypes
#include "device_cache.h"
#include "JDI_MLCD_driver/JDI_MIP_Display2.h"

#define TEMP_SENSOR_SLAVE_ADDR                  0x004F
#define TEMP_SENSOR_REG_ADDR                    0x00

#define SWITCH_0                                0   // Switch 0 is pressed
#define SWITCH_1                                1   // Switch 1 is pressed

/* Timer Counter Time period match values for input clock of 4096 Hz */
#define PERIOD_500MS                    512
#define PERIOD_1S                       1024
#define PERIOD_2S                       2048
#define PERIOD_4S                       4096

#define Version_Nrd '1'
#define Version_Nrf1 '4' //2._x
#define Version_Nrf2 '1' //2.x_

char version_buf[4];


extern void JDI_Display_init();
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
uint32_t systck_val_tmp = 0;
uint32_t systck_interval = 0;

static volatile bool isRTCExpired = false;
static volatile bool changeTempSamplingRate = false;
static volatile bool startTemperatureReading = false;
static volatile uint8_t temperatureReadStartMsgLen = 0x00;
static volatile bool isUARTTxComplete = true;
static volatile bool isTemperatureRead = false;
static volatile uint8_t curSwitchPressedState = SWITCH_0;
static volatile uint8_t preSwitchPressedState = SWITCH_0;
//static volatile uint8_t curSwitchPressedState1 = SWITCH_1;
//static volatile uint8_t preSwitchPressedState1 = SWITCH_1;

static uint8_t temperatureVal;
//static uint8_t i2cWrData = TEMP_SENSOR_REG_ADDR;
static uint8_t i2cRdData[2] = {0};
static uint8_t uartTxBuffer[100] = {0};

static uint8_t SPI_TxBuffer[4] = {0};

uint16_t SW0_press_cnt = 0;
uint16_t SW1_press_cnt = 0;

//-------------JDI LCD test vars-----------
uint16_t pixel_pos_x = 0;
uint16_t pixel_pos_y = 0;
uint16_t pixel_line_idx = 0;

typedef enum {
    TEMP_SAMPLING_RATE_500MS = 0,
    TEMP_SAMPLING_RATE_1S = 1,
    TEMP_SAMPLING_RATE_2S = 2,
    TEMP_SAMPLING_RATE_4S = 3,
} TEMP_SAMPLING_RATE;

static TEMP_SAMPLING_RATE tempSampleRate = TEMP_SAMPLING_RATE_500MS;
static const char timeouts[4][20] = {"500 milliSeconds", "1 Second", "2 Seconds", "4 Seconds"};

static void sw0_userHandler(uintptr_t context) {
    PB01_MISO_Set(); //5us time cost?
    curSwitchPressedState = SWITCH_0;

    startTemperatureReading = false;
    if (preSwitchPressedState == curSwitchPressedState) {
        changeTempSamplingRate = true;
    } else {
        sprintf((char*) uartTxBuffer, "************* Printing Toggling LED rate *************\r\n");
        temperatureReadStartMsgLen = strlen((const char*) uartTxBuffer);
        DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        temperatureReadStartMsgLen);


        while (false == SERCOM3_USART_TransmitComplete()) {
            _nop();
        }
    }
    preSwitchPressedState = SWITCH_0;

//    if (0= SW0_press_cnt) {
//        JDI_Display_BlinkWhite();
//        printf("#>:JDI screen turn all white!\r\n");
   // } else {
        printf("#>:JDI draw Green Line at line idx %u\r\n", pixel_pos_y);
        for (uint16_t x_pos = 0; x_pos < JDI_DISPLAY_Width; x_pos++) {
            JDI_Display_drawPixel(x_pos, pixel_pos_y, COLOR_GREEN);
        }
        //JDI_Display_refresh();
        JDI_Display_refresh_line(pixel_pos_y) ; //test working!
    //}

    SW0_press_cnt++;
    PB01_MISO_Clear();
}

static void sw1_userHandler(uintptr_t context) {

    PB01_MISO_Set(); //2us time cost?
    curSwitchPressedState = SWITCH_1;

    startTemperatureReading = true;
    if (preSwitchPressedState == curSwitchPressedState) {
        changeTempSamplingRate = true;
    } else {
        sprintf((char*) uartTxBuffer, "************* JDI draw pixels / Printing Temperature *************\r\n");
        temperatureReadStartMsgLen = strlen((const char*) uartTxBuffer);
        DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        temperatureReadStartMsgLen);


        while (false == SERCOM3_USART_TransmitComplete()) {
            _nop();
        }

    }
    preSwitchPressedState = SWITCH_1;

    if (0 == SW1_press_cnt) {
        JDI_Display_displayOn();
        printf("#>:JDI screen Power ON!\r\n");
    }
    else if (1 == SW1_press_cnt) {

        JDI_Display_BlinkBlack();
        printf("#>:JDI screen turn BLACK!\r\n");
    }
    else if ( 2== SW1_press_cnt) {
        JDI_Display_BlinkWhite();
        printf("#>:JDI screen turn all white(BLINK)!\r\n");
    }
        else if ( 3== SW1_press_cnt) {
        JDI_Display_BlinkOFF();
        printf("#>:JDI screen BLINK OFF!\r\n");
    }
        else if( 6== SW1_press_cnt){
            
            JDI_Display_INVERSION();
             printf("#>:JDI screen BLINK inversion!\r\n");
        }
         else if( 7== SW1_press_cnt){
            
            JDI_Display_BlinkOFF();
             printf("#>:JDI screen disable inversion!\r\n");
        }
    
    else {
        printf("#>:JDI draw pixel blue at %u,%u(x,y)\r\n", pixel_pos_x, pixel_pos_y);
        JDI_Display_drawPixel(pixel_pos_x, pixel_pos_y, COLOR_BLUE);
        JDI_Display_refresh_line(pixel_pos_y) ;
        
        //JDI_Display_refresh();
        /*  test code for SPI, works!
        printf("#>:SPI write uartTxBuffer test!\r\n");
        SPI_TxBuffer[0]= 0x55;
        SPI_TxBuffer[1]= 0x01;
        SPI_TxBuffer[3]= 0xAA;
        SERCOM5_SPI_Write(SPI_TxBuffer, sizeof (SPI_TxBuffer));
         */
        pixel_pos_x=JDI_DISPLAY_Width/2;
        pixel_pos_y++;
    }
    if (JDI_DISPLAY_Width <= pixel_pos_x) {
        pixel_line_idx++;
        pixel_pos_y = pixel_line_idx;
        pixel_pos_x = 0;
    }
    if (JDI_DISPLAY_Height <= pixel_line_idx) {

        pixel_line_idx = 0;
        pixel_pos_y = pixel_line_idx;
    }
    if (15 < SW1_press_cnt) {
        JDI_Display_clearScreen();
        printf("#>: JDI screen cleared!\r\n");
    }
    SW1_press_cnt++;
    PB01_MISO_Clear();
}

static void rtcEventHandler(RTC_TIMER32_INT_MASK intCause, uintptr_t context) {
    if (intCause & RTC_MODE0_INTENSET_CMP0_Msk) {
        isRTCExpired = true;
    }
}

//static void i2cEventHandler(uintptr_t contextHandle)
//{
//    if (SERCOM5_I2C_ErrorGet() == SERCOM_I2C_ERROR_NONE)
//    {
//        isTemperatureRead = true;
//    }
//}

static void uartDmaChannelHandler(DMAC_TRANSFER_EVENT event, uintptr_t contextHandle) {
    if (event == DMAC_TRANSFER_EVENT_COMPLETE) {
        isUARTTxComplete = true;
    }
}

static uint8_t getTemperature(uint8_t* rawTempValue) {
    int16_t temp;
    // Convert the temperature value read from sensor to readable format (Degree Celsius)
    // For demonstration purpose, temperature value is assumed to be positive.
    // The maximum positive temperature measured by sensor is +125 C
    temp = (rawTempValue[0] << 8) | rawTempValue[1];
    temp = (temp >> 7) * 0.5;
    temp = (temp * 9 / 5) + 32;
    return (uint8_t) temp;
}

static void toggleLED_BasedOnSwitchPress(void) {
    if (curSwitchPressedState == SWITCH_0) {
        LED1_Set();
        LED0_Toggle();
    } else {
        LED0_Set();
        LED1_Toggle();
    }
}



int main(void) {
    uint8_t uartLocalTxBuffer[100] = {0};

    /* Initialize all modules */
    SYS_Initialize(NULL);
    JDI_Display_init();
    PB00_CS_OutputEnable();
    PB01_MISO_OutputEnable();


    // PB00_CS_Set()  ;
    //RTC_Timer32Stop();
    //SERCOM5_I2C_CallbackRegister(i2cEventHandler, 0);
    DMAC_ChannelCallbackRegister(DMAC_CHANNEL_0, uartDmaChannelHandler, 0);
    RTC_Timer32CallbackRegister(rtcEventHandler, 0);
    EIC_CallbackRegister(EIC_PIN_4, sw1_userHandler, 0);
    EIC_CallbackRegister(EIC_PIN_12, sw0_userHandler, 1);
    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, "\r\n\r\n<PIC32CM5164 LE00 C-Pro demo by Zell>\r\n");
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));


    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
    }

    version_buf[0] = Version_Nrd;
    version_buf[1] = '.';
    version_buf[2] = Version_Nrf1;
    version_buf[3] = Version_Nrf2;

    printf("-Version %sB, 28.Mar.2025 by Zell-\r\n", version_buf);

    printf(">>:press SW0 and SW 1 to toggle LED, PB00(SPI_CS) is also triggered to show EIC INT time cost about 2us! >\r\n");
    PB00_CS_Clear();

    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, "--FW code compiled: %s %s\r\n", __DATE__, __TIME__);
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
    }
    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    //memset(uartTxBuffer,NULL,sizeof(uartTxBuffer));
    sprintf((char*) uartTxBuffer, "--FW code compiled with XC32 Version: %d\n", __XC32_VERSION__); //--FW code compiled with XC16 Version: 3020
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));





    //    sprintf((char*)uartTxBuffer,">>: SW1 function--Please plug in I/O1 XPLAINED PRO EXTENSION KIT for T measurement!\r\n", __XC32_VERSION__ );//--FW code compiled with XC16 Version: 3020
    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, ">>:SerCOM5 as SPI function to drive OLED!\r\n"); //--FW code compiled with XC16 Version: 3020
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
        //NOP();
    }


    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, ">>:SerCOM3 as UART with sprintf support for debugging!\r\n"); //--FW code compiled with XC16 Version: 3020
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
        //NOP();
    }
    //JDI test
    //JDI_Display_displayOn();
    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, ">>:Press SW2 to switch JDI_Display  On!\r\n"); //--FW code compiled with XC16 Version: 3020
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
        //NOP();
    }

    SYSTICK_TimerStart();
    systck_val_tmp = SYSTICK_TimerCounterGet();
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
    }
    systck_interval = SYSTICK_TimerCounterGet() - systck_val_tmp;

    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, ">>:Sys_tck cost %lu \r\n", systck_interval); //--FW code compiled with XC16 Version: 3020
    while (false == SERCOM3_USART_TransmitComplete()) {
        _nop();
    }
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));

    memset(uartTxBuffer, '\0', sizeof (uartTxBuffer));
    sprintf((char*) uartTxBuffer, "************* Printing Toggling LED rate *************\r\n");

    temperatureReadStartMsgLen = 0;
    DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
        (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*) uartTxBuffer));

    /* Start the timer */
    RTC_Timer32Start();

    while (true) {
        while (false == startTemperatureReading) {
            if ((isRTCExpired == true) && (true == isUARTTxComplete)) {
                isRTCExpired = false;
                isUARTTxComplete = false;
                toggleLED_BasedOnSwitchPress();
                sprintf((char*) (uartTxBuffer + temperatureReadStartMsgLen), "Toggling LED at %s rate \r\n", &timeouts[(uint8_t) tempSampleRate][0]);
                temperatureReadStartMsgLen = 0;
                DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
                    (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
                    strlen((const char*) uartTxBuffer));
            }
            if (changeTempSamplingRate == true) {
                changeTempSamplingRate = false;
                if (tempSampleRate == TEMP_SAMPLING_RATE_500MS) {
                    tempSampleRate = TEMP_SAMPLING_RATE_1S;
                    RTC_Timer32CompareSet(PERIOD_1S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_1S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_2S;
                    RTC_Timer32CompareSet(PERIOD_2S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_2S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_4S;
                    RTC_Timer32CompareSet(PERIOD_4S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_4S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_500MS;
                    RTC_Timer32CompareSet(PERIOD_500MS);
                } else {
                    ;
                }
                RTC_Timer32CounterSet(0);
                sprintf((char*) uartLocalTxBuffer, "LED Toggling rate is changed to %s\r\n", &timeouts[(uint8_t) tempSampleRate][0]);
                DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartLocalTxBuffer, \
                    (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
                    strlen((const char*) uartLocalTxBuffer));
            }
        }
        if (isRTCExpired == true) {
            isRTCExpired = false;
            //SERCOM5_I2C_WriteRead(TEMP_SENSOR_SLAVE_ADDR, &i2cWrData, 1, i2cRdData, 2);
        }
        if (isTemperatureRead == true) {
            isTemperatureRead = false;
            if (changeTempSamplingRate == false) {
                temperatureVal = getTemperature(i2cRdData);
                sprintf((char*) (uartTxBuffer + temperatureReadStartMsgLen), "Temperature = %02d F\r\n", temperatureVal);
                temperatureReadStartMsgLen = 0;
                toggleLED_BasedOnSwitchPress();
            } else {
                changeTempSamplingRate = false;
                RTC_Timer32CounterSet(0);
                if (tempSampleRate == TEMP_SAMPLING_RATE_500MS) {
                    tempSampleRate = TEMP_SAMPLING_RATE_1S;
                    sprintf((char*) uartTxBuffer, "Sampling Temperature every 1 second \r\n");
                    RTC_Timer32CompareSet(PERIOD_1S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_1S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_2S;
                    sprintf((char*) uartTxBuffer, "Sampling Temperature every 2 seconds \r\n");
                    RTC_Timer32CompareSet(PERIOD_2S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_2S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_4S;
                    sprintf((char*) uartTxBuffer, "Sampling Temperature every 4 seconds \r\n");
                    RTC_Timer32CompareSet(PERIOD_4S);
                } else if (tempSampleRate == TEMP_SAMPLING_RATE_4S) {
                    tempSampleRate = TEMP_SAMPLING_RATE_500MS;
                    sprintf((char*) uartTxBuffer, "Sampling Temperature every 500 ms \r\n");
                    RTC_Timer32CompareSet(PERIOD_500MS);
                } else {
                    ;
                }
                RTC_Timer32Start();
            }
            DMAC_ChannelTransfer(DMAC_CHANNEL_0, uartTxBuffer, \
                    (const void *) &(SERCOM3_REGS->USART_INT.SERCOM_DATA), \
                    strlen((const char*) uartTxBuffer));
        }
    }
    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE);
}

//
/*
>>: Temperature sensor AT30TSE758A?LM75?? not exist! Please check connection!
>>: Please plug in I/O1 XPLAINED PRO EXTENSION KIT for T measurement!
 * 
 * 
 * 
 * // PIC32CM5164LE00100 Configuration Bit Settings

// 'C' source line config statements

// Config Source code for XC32 compiler.
// USER_WORD_0
#pragma config NVMCTRL_SULCK = 0x7 // Enter Hexadecimal value
#pragma config NVMCTRL_NSULCK = 0x6 // Enter Hexadecimal value
#pragma config BOD33USERLEVEL = 0x6 // Enter Hexadecimal value
#pragma config BOD33_DIS = CLEAR
#pragma config BOD33_ACTION = 0x1 // Enter Hexadecimal value
#pragma config WDT_RUNSTDBY = CLEAR
#pragma config WDT_ENABLE = CLEAR
#pragma config WDT_ALWAYSON = CLEAR
#pragma config WDT_PER = 0xB // Enter Hexadecimal value

// USER_WORD_1
#pragma config WDT_WINDOW = 0xB // Enter Hexadecimal value
#pragma config WDT_EWOFFSET = 0xB // Enter Hexadecimal value
#pragma config WDT_WEN = CLEAR
#pragma config BOD33_HYST = CLEAR

// BOCOR_WORD_1
#pragma config BOOTROM_BOOTPROT = 0x0 // Enter Hexadecimal value

// BOCOR_WORD_16
#pragma config BOOTROM_CRCKEY_0 = 0xFFFFFFFF // Enter Hexadecimal value

// BOCOR_WORD_17
#pragma config BOOTROM_CRCKEY_1 = 0xFFFFFFFF // Enter Hexadecimal value

// BOCOR_WORD_18
#pragma config BOOTROM_CRCKEY_2 = 0xFFFFFFFF // Enter Hexadecimal value

// BOCOR_WORD_19
#pragma config BOOTROM_CRCKEY_3 = 0xFFFFFFFF // Enter Hexadecimal value

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
 */
/*******************************************************************************
 End of File
 */



// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
//
//int main ( void )
//{
//    /* Initialize all modules */
//    SYS_Initialize ( NULL );
//
//    while ( true )
//    {
//        /* Maintain state machines of all polled MPLAB Harmony modules. */
//        SYS_Tasks ( );
//    }
//
//    /* Execution should not come here during normal operation */
//
//    return ( EXIT_FAILURE );
//}


/*******************************************************************************
 End of File
 */

//