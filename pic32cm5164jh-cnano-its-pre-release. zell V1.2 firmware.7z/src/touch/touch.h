/*============================================================================
Filename : touch.h
Project : QTouch Modular Library
Purpose : configuration macros for touch library

Usage License: Refer license.h file for license information
Support: Visit http://www.microchip.com/support/hottopics.aspx
               to create MySupport case.

------------------------------------------------------------------------------
Copyright (c) 2023 Microchip. All rights reserved.
------------------------------------------------------------------------------
============================================================================*/

#ifndef TOUCH_H
#define TOUCH_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/*----------------------------------------------------------------------------
 *     include files
 *----------------------------------------------------------------------------*/

#include "definitions.h"
#include "touch_api.h"

/**********************************************************/
/******************* Acquisition controls *****************/
/**********************************************************/
/* Defines the Measurement Time in milli seconds.
 * Range: 1 to 255.
 * Default value: 20.
 */
#define DEF_TOUCH_MEASUREMENT_PERIOD_MS 30u

/*----------------------------------------------------------------------------
 *     defines
 *----------------------------------------------------------------------------*/

/**********************************************************/
/***************** Acquisition Parameters *****************/
/**********************************************************/

/*
 *      < Automated ITS Acquisition Library for SAMC21 & PIC32CM JH >
 *      
 *      The automated ITS library supports a maximum of:
 *          - 10 sensors for SAMC21E/G/J and PIC32CM JH
 *          -  6 sensors for SAMC21N
 * 
 *      Both sensor pin and sample cap pin must be on PORTA
 * 
 *      The sample cap pin of each sensor must be connected to ADC0 (PA02-PA11)
 * 
 *      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *      Sensor node order is determined by the ADC channel number (AIN0-AIN11)
 *      Please assign sensor nodes in order of increasing AIN channel number
 *      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 */

/* Defines the number of sensors in the acquisition set.
 * 
 * Range:
 *  - 1 to 10 for SAMC21E/G/J and PIC32CM JH
 *  - 1 to  6 for SAMC21N
 */
#define DEF_NUM_CHANNELS 1u  // original 2u

#if (DEF_NUM_CHANNELS > 10u)
#error ("DEF_NUM_CHANNELS must be <= 10")
#endif

/* Defines the number of pulses per measurement.
 * Recommended Range: 300 to 600.
 * Default value: 300.
 */
#define NUM_PULSES          600u

/* Defines the acquisition pulse setting.
 *  This parameter should be used for tuning the series R for each sensor.
 *  Once the series R has been tuned, PULSE_SETTING_1 should be used for best
 *  water rejection performance.
 * 
 * Range: (PULSE_SETTING_1 | PULSE_SETTING_2).
 * Default value: PULSE_SETTING_1.
 */
#define PULSE_SETTING         PULSE_SETTING_1

/* Defines the acquisition frequency(s).
 *  This parameter should be used for adjusting the acquisition frequency in
 *  case that is needed to pass tests (e.g. radiated emissions, radiated
 *  immunity, conducted immunity).
 * 
 * Range: 40 to 400 (1.2 MHz to 120 kHz @ 48 MHz MCLK).
 * Default value: 40.
 */
#define ACQ_FREQ_DELAY 40u

/* Enables/disables spread spectrum acquisition, which is a noise 
 *  countermeasure. When enabled, the acquisition will be spread among three
 *  different frequencies.
 *  - F0 is set by ACQ_FREQ_DELAY
 *  - F1 is 10% lower than F0
 *  - F2 is 10% lower than F1
 * 
 * Range: 0 or 1.
 * Default value: 1.
 */
#define SPREAD_SPEC_ENABLE  1u

/* Defines the number of over-samples in each measurement.
 *  ITS is fundamentally different that PTC/CVD in the sense that oversampling
 *  is done in the analog domain by accumulating charge from many short pulses
 *  on the sample capacitor. More pulses provide higher SNR, but the sample
 *  capacitor must be tuned accordingly. The FILTER_LEVEL parameter for software
 *  oversampling has been included as a secondary option to provide flexibility
 *  when hardware modifications are troublesome.
 * 
 * Range: 1, 2, 4, 8, or 16.
 * Default value: 1.
 */
#define FILTER_LEVEL        FILTER_LEVEL_1

/* Defines the delay in microseconds between samples. This applies to both
 *  over-samples when FILTER_LEVEL is greater than 1 and re-bursts triggered by
 *  the keys module. This parameter should be tuned based on the size of the
 *  largest sample capacitor used in the acquisition set. There must be enough
 *  delay so that the sample capacitor can fully discharge between samples.
 */
#define OVERSAMPLE_DELAY    100u

/* Defines the DMA channels configured and reserved for the ITS library
 * DMA Channel 1: ITS waveform generation
 * DMA Channel 2: ADC result transfer
 */
#define DMA_CH_1            DMAC_CHANNEL_0
#define DMA_CH_2            DMAC_CHANNEL_1
#define DMA_CH_3            DMAC_CHANNEL_2

/* Defines ITS Node Configuration
 * {sensor pin, sample cap pin, digital gain}
 * 
 * Digital Gain
 * Range: 1, 2, 4, 8, or 16 (must be less than or equal to the filter level)
 * Default value: 1.
 */
    
//#define NODE_0_PARAMS {2u, 3u, GAIN_1}  //not working
#define NODE_0_PARAMS {15u, 7u, GAIN_1} //ori is working
#define NODE_1_PARAMS {12u, 9u, GAIN_1}

/**********************************************************/
/******************** Key Parameters   ********************/
/**********************************************************/
/* Defines the number of key sensors
 * Range: 1 to 65535.
 * Default value: 1
 */
#define DEF_NUM_SENSORS (DEF_NUM_CHANNELS)

/* Defines Key Sensor setting
 * {Sensor Threshold, Sensor Hysteresis, Sensor AKS}
 */
#define KEY_0_PARAMS                                                            \
	{                                                                           \
		40, HYST_6_25, NO_AKS_GROUP                                             \
	}

#define KEY_1_PARAMS                                                            \
	{                                                                           \
		50, HYST_6_25, NO_AKS_GROUP                                             \
	}
    
/* De-bounce counter for additional measurements to confirm touch detection
 * Range: 0 to 255.
 * Default value: 4.
 */
#define DEF_TOUCH_DET_INT 4

/* De-bounce counter for additional measurements to confirm away from touch signal
 * to initiate Away from touch re-calibration.
 * Range: 0 to 255.
 * Default value: 5.
 */
#define DEF_ANTI_TCH_DET_INT 5

/* Threshold beyond with automatic sensor re-calibration is initiated.
 * Range: RECAL_100/ RECAL_50 / RECAL_25 / RECAL_12_5 / RECAL_6_25 / MAX_RECAL
 * Default value: RECAL_100.
 */
#define DEF_ANTI_TCH_RECAL_THRSHLD RECAL_50

/* Rate at which sensor reference value is adjusted towards sensor signal value
 * when signal value is greater than reference.
 * Units: 200ms
 * Range: 0-255
 * Default value: 20u = 4 seconds.
 */
#define DEF_TCH_DRIFT_RATE 1

/* Rate at which sensor reference value is adjusted towards sensor signal value
 * when signal value is less than reference.
 * Units: 200ms
 * Range: 0-255
 * Default value: 5u = 1 second.
 */
#define DEF_ANTI_TCH_DRIFT_RATE 1

/* Amount to drift each drift period.
 * Range: 1-10
 * Default value: 1u = 1 count per 200ms.
 */
#define DEF_TCH_DRIFT_STEP 1

/* Time to restrict drift on all sensor when one or more sensors are activated.
 * Units: 200ms
 * Range: 0-255
 * Default value: 20u = 4 seconds.
 */
#define DEF_DRIFT_HOLD_TIME 0

/* Set mode for additional sensor measurements based on touch activity.
 * Range: REBURST_NONE / REBURST_UNRESOLVED / REBURST_ALL
 * Default value: REBURST_UNRESOLVED
 */
#define DEF_REBURST_MODE REBURST_NONE

/* Sensor maximum ON duration upon touch.
 * Range: 0-255
 * Default value: 0
 */
#define DEF_MAX_ON_DURATION 0

/**********************************************************/
/******************* Low-Power Parameters *****************/
/**********************************************************/
/* Enable or disable low-power scan 
 * Range: 0 or 1.
 * Default value: 1
*/
#define DEF_TOUCH_LOWPOWER_ENABLE 0u

/* Touch inactive time before entering low power mode
 * Range : 1 to 65535
 * Default: 3000
 */
#define DEF_TOUCH_LOWPOWER_TIMEOUT_MS 3000u

/* Low power Touch measurement periodicity
 * defines the interval between low-power touch measurement.
 * Range : 1 to 65535
 * Default: 100
*/
#define DEF_TOUCH_LP_MEASUREMENT_PERIOD_MS 100u

/******************************************************************/
/***************** Communication - Data Streamer ******************/
/******************************************************************/

#define DEF_TOUCH_DATA_STREAMER_ENABLE 1u

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // TOUCH_C
