/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
//UART_TXD  PB02  SERCOM5  SERCOM5 USART baud value for 115200 Hz baud rate
//UART_RXD    PB03   SERCOM5

//code modified by ZELL
//last edit: 6.Nov.2025
//V1.1 added printf support! //need to include stdio in definitions.h, add STDIO_BufferModeSet(); in init...c
//modifiy xc32_monitor  as https://support.microchip.com/s/article/Adding-the--printf----function-to-your-application
//V1.0 adjust touch paras, touch is working

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "touch/touch.h"

#include <stdio.h>
#include <string.h>




#define UART5_TEST_ENABLE 
#define UART5_printf_Debug_EN
//#define UART5_debug_touch_hex_value_EN
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

extern volatile uint8_t                 measurement_done_touch;
extern volatile uint8_t                 touch_measurement_in_progress;
extern          qtm_touch_key_control_t qtlib_key_set1;




#ifdef UART5_TEST_ENABLE    
#define TX_BUFFER_SIZE 100

static volatile bool isUARTTxComplete = true;
static uint8_t uartTxBuffer[TX_BUFFER_SIZE] = {0};

static void uart5DmaChannelHandler_Tx(DMAC_TRANSFER_EVENT event, uintptr_t contextHandle)
{
    if (event == DMAC_TRANSFER_EVENT_COMPLETE)
    {
        isUARTTxComplete = true;
    }
}
#endif

void print_touch_delta(uint16_t delta);

void print_touch_delta_all();

    uint16_t touch_delta0 = 0;
    uint16_t touch_delta1 = 0;
     uint16_t touch_delta2 = 0;
    uint16_t touch_delta3 = 0;
     uint16_t touch_delta4 = 0;
    uint16_t touch_delta5 = 0;

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
#ifdef UART5_printf_Debug_EN
    printf("< PIC32CM2531JH ITS test demo>\r\n");
    printf("-Version 1.1, 06.Nov.2025 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC32 Version: %d\n", __XC32_VERSION__);
#endif
    
    touch_init();
    uintptr_t dma_context3=0;
#ifdef UART5_TEST_ENABLE    
    
    DMAC_ChannelCallbackRegister(DMAC_CHANNEL_3, uart5DmaChannelHandler_Tx, dma_context3);
    sprintf((char*)uartTxBuffer, "*************PIC32CM2531JH ITS test begin *************\r\n");
    DMAC_ChannelTransfer(DMAC_CHANNEL_3, uartTxBuffer, \
        (const void *)&(SERCOM5_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*)uartTxBuffer));
    //DMA UART semms not working!
#endif
    dma_context3 =0;
    dma_context3 ++;
    SYSTICK_TimerStart();

    bool touch_valid = false;
    uint16_t touch_signal = 0;
    printf(" ITS touch loop starts now...\r\n");
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        
        touch_process();
        
        if (measurement_done_touch)
        {
            measurement_done_touch = 0u;
             touch_valid = false ;
            if (qtlib_key_set1.qtm_touch_key_data[0u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(0) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
//                LED_1_Set();
                GPIO_PA21_Set();
                /* Touch delta */
                touch_signal = get_sensor_node_signal(0);
		        touch_delta0 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[0].channel_reference );
                touch_valid = true ;
                
            } else {
//                LED_1_Clear();
                GPIO_PA21_Clear();
                touch_delta0 = 0;
            }

            if (qtlib_key_set1.qtm_touch_key_data[1u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(1) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
//                LED_2_Set();
                GPIO_PA20_Set();
                 touch_valid = true ;
                 touch_signal = get_sensor_node_signal(1);
		        touch_delta1 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[1].channel_reference );
            } else {
//                LED_2_Clear();
                GPIO_PA20_Clear();
                touch_delta1 = 0;
            }
        
            if (qtlib_key_set1.qtm_touch_key_data[2u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(2) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
                GPIO_PA19_Set();
                 touch_valid = true ;
                 touch_signal = get_sensor_node_signal(2);
		        touch_delta2 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[2].channel_reference );
            } else {
                GPIO_PA19_Clear();
                touch_delta2 = 0;
            }
        
            if (qtlib_key_set1.qtm_touch_key_data[3u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(3) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
                GPIO_PA18_Set();
                 touch_valid = true ;
                 touch_signal = get_sensor_node_signal(3);
		        touch_delta3 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[3].channel_reference );
            } else {
                GPIO_PA18_Clear();
                touch_delta3 = 0;
            }
        
            if (qtlib_key_set1.qtm_touch_key_data[4u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(4) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
                GPIO_PA17_Set();
                 touch_valid = true ;
                touch_signal = get_sensor_node_signal(4);
		        touch_delta4 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[4].channel_reference );
            } else {
                GPIO_PA17_Clear();
                touch_delta4 = 0;
            }
            
            if (qtlib_key_set1.qtm_touch_key_data[5u].sensor_state & KEY_TOUCHED_MASK)
//            if((get_sensor_state(5) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT)
            {
                GPIO_PA16_Set();
                 touch_valid = true ;
                touch_signal = get_sensor_node_signal(5);
		        touch_delta5 = (uint16_t) (touch_signal - qtlib_key_set1.qtm_touch_key_data[5].channel_reference );
            } else {
                GPIO_PA16_Clear();
                touch_delta5 = 0;
            }
            
            
            //if (0!=touch_delta){
                if (touch_valid){
#ifdef UART5_printf_Debug_EN
               // print_touch_delta(touch_delta0);
                print_touch_delta_all();
#endif
                
            }
            
            
            
            
            
            
        }
        
        /* If interrupts need to be disabled temporarily by the application, 
           then the application must first check to make sure that a touch
           measurement is not in progress before disabling interrupts. 
         */
        if (!touch_measurement_in_progress)
        {
            __disable_irq();
            /* critical task */
            __enable_irq();
        }
        
        
//        GPIO_PA16_Toggle();
//        GPIO_PA17_Toggle();
//        GPIO_PA18_Toggle();
//        GPIO_PA19_Toggle();
//        GPIO_PA20_Toggle();
//        GPIO_PA21_Toggle();
//        SYSTICK_DelayMs(250);
        
        
#if DEF_TOUCH_LOWPOWER_ENABLE
        PM_StandbyModeEnter();
#endif
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}

void print_touch_delta(uint16_t delta){
    
    //SERCOM5_USART_WriteByte(0x55);
#ifdef UART5_debug_touch_hex_value_EN
    uint8_t Data_MSB = 0;
    uint8_t Data_LSB = 0 ;
        Data_MSB = delta>>8;
    Data_LSB = 0xFF&delta;
    SERCOM5_USART_WriteByte(Data_MSB);
    SERCOM5_USART_WriteByte(Data_LSB);
#endif
    printf(">>:touch delta:%d\r\n", delta); //not working, working now!
    /*
    sprintf((char*)uartTxBuffer, ">>Current Touch delta: %d\r\n", delta);
    
    DMAC_ChannelTransfer(DMAC_CHANNEL_3, uartTxBuffer, \
        (const void *)&(SERCOM5_REGS->USART_INT.SERCOM_DATA), \
        strlen((const char*)uartTxBuffer));
     */


}

void print_touch_delta_all(){
    
      printf(">>:touch delta 0:%d\r\n", touch_delta0); //
      printf(">>:touch delta 1:%d\r\n", touch_delta1); //
      printf(">>:touch delta 2:%d\r\n", touch_delta2); //
      printf(">>:touch delta 3:%d\r\n", touch_delta3); //      
      printf(">>:touch delta 4:%d\r\n", touch_delta4); //
      printf(">>:touch delta 5:%d\r\n", touch_delta5); //
      printf("-----------------------\n"); //
    
}

//example output:
/*
>>:touch delta 0:643
>>:touch delta 1:902

>>:touch delta 2:857

>>:touch delta 3:900

>>:touch delta 4:997
>>:touch delta 5:1044

*/
/*******************************************************************************
 End of File
*/

