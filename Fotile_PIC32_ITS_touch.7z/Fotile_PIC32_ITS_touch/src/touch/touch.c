/*============================================================================
Filename : touch.c
Project : QTouch Modular Library
Purpose : Provides Initialization, Processing and ISR handler of touch library,
          Simple API functions to get/set the key touch parameters from/to the
          touch library data structures

Usage License: Refer license.h file for license information
Support: Visit http://www.microchip.com/support/hottopics.aspx
               to create MySupport case.

------------------------------------------------------------------------------
Copyright (c) 2023 Microchip. All rights reserved.
------------------------------------------------------------------------------
============================================================================*/
#ifndef TOUCH_C
#define TOUCH_C

/*----------------------------------------------------------------------------
 *     include files
 *----------------------------------------------------------------------------*/

#include "touch.h"
#include "license/license.h"

#include "./datastreamer/datastreamer.h"

/*----------------------------------------------------------------------------
 *   prototypes
 *----------------------------------------------------------------------------*/

static void qtm_error_callback(uint8_t error);

static void touch_timer_config(void);

#if DEF_TOUCH_LOWPOWER_ENABLE == 1u
void touch_enable_lowpower_measurement(void);
void touch_disable_lowpower_measurement(void);
#endif

/* ITS library callback functions */
static void qtm_tmr1_period_set_callback (uint16_t period);
static void qtm_tmr2_period_set_callback (uint16_t period);
static void qtm_start_timers_callback (void);
static void qtm_stop_timers_callback (void);

/*----------------------------------------------------------------------------
 *     Global Variables
 *----------------------------------------------------------------------------*/

#if DEF_TOUCH_LOWPOWER_ENABLE == 1u
uint16_t measurement_period_store = DEF_TOUCH_MEASUREMENT_PERIOD_MS;
uint16_t time_since_touch = 0u;
#endif

/* Flag to indicate time for touch measurement */
volatile uint8_t time_to_measure_touch_flag = 0;

/* Flag to indicate time for touch measurement */
volatile uint8_t touch_measurement_in_progress = 0;

/* Oversample process request flag */
volatile uint8_t oversample_process_request = 0;

/* Postprocess request flag */
volatile uint8_t touch_postprocess_request = 0;

/* Measurement Done Touch Flag  */
volatile uint8_t measurement_done_touch = 0;

/* Error Handling */
uint8_t module_error_code = 0;

/* Filter Level / Digital Gain */
volatile uint8_t oversamples = 0u;

static uint16_t    median_buffer[DEF_NUM_CHANNELS*NUM_FREQ]= {0u};
static uint8_t     pulse_times[NUM_FREQ] = {SPREAD_FREQS};
/**********************************************************/
/******************* Acquisition Module *******************/
/**********************************************************/

/* Node configuration */
#if (DEF_NUM_CHANNELS == 1u)
its_acq_node_config_t its_node_config[DEF_NUM_CHANNELS] = {NODE_0_PARAMS};
#elif (DEF_NUM_CHANNELS == 2u)
its_acq_node_config_t its_node_config[DEF_NUM_CHANNELS] = {NODE_0_PARAMS, NODE_1_PARAMS};
#elif (DEF_NUM_CHANNELS == 6u)
its_acq_node_config_t its_node_config[DEF_NUM_CHANNELS] = 
    {NODE_0_PARAMS, NODE_1_PARAMS, NODE_2_PARAMS, NODE_3_PARAMS, NODE_4_PARAMS, NODE_5_PARAMS};
#else
#error
#endif

/* Acquisition set configuration */
its_acq_set_config_t its_acq_set_config1 = {
    DEF_NUM_CHANNELS,
    &its_node_config[0u],
    NUM_PULSES,
    PULSE_SETTING,
    SPREAD_SPEC_ENABLE,
    FILTER_LEVEL,
    DMA_CH_1,
    DMA_CH_2,
    DMA_CH_3,
    NUM_FREQ,
    &median_buffer[0],
    &pulse_times[0]
};

/* Node signal values */
its_acq_node_data_t its_node_stat1[DEF_NUM_CHANNELS];

its_acq_node_data_t its_node_accumulated_signals[DEF_NUM_CHANNELS] = {0u};

/* Container */
its_acq_control_t its_acq_control1 = {
    &its_acq_set_config1, &its_node_stat1[0u]
};

/**********************************************************/
/*********************** Keys Module **********************/
/**********************************************************/

/* Keys set 1 - General settings */
qtm_touch_key_group_config_t qtlib_key_grp_config_set1 = {
    DEF_NUM_SENSORS,
    DEF_TOUCH_DET_INT,
    DEF_MAX_ON_DURATION,
    DEF_ANTI_TCH_DET_INT,
    DEF_ANTI_TCH_RECAL_THRSHLD,
    DEF_TCH_DRIFT_RATE,
    DEF_ANTI_TCH_DRIFT_RATE,
    DEF_TCH_DRIFT_STEP,
    DEF_DRIFT_HOLD_TIME,
    DEF_REBURST_MODE
};

qtm_touch_key_group_data_t qtlib_key_grp_data_set1;

/* Key data */
qtm_touch_key_data_t qtlib_key_data_set1[DEF_NUM_SENSORS];

/* Key Configurations */
#if (DEF_NUM_CHANNELS == 1u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {KEY_0_PARAMS};
#elif (DEF_NUM_CHANNELS == 2u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {KEY_0_PARAMS, KEY_1_PARAMS};
#elif (DEF_NUM_CHANNELS == 6u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = 
    {KEY_0_PARAMS, KEY_1_PARAMS, KEY_2_PARAMS, KEY_3_PARAMS, KEY_4_PARAMS, KEY_5_PARAMS};
#else
#error
#endif

/* Container */
qtm_touch_key_control_t qtlib_key_set1
    = {&qtlib_key_grp_data_set1, &qtlib_key_grp_config_set1, &qtlib_key_data_set1[0], &qtlib_key_configs_set1[0]};

/* Harmony Peripheral Library Abstraction Callback Functions */

/* ITS Acquisition Callback - Timer 1 Period Set */
static void qtm_tmr1_period_set_callback (uint16_t period)
{
    TC0_Timer16bitPeriodSet(period);
}

/* ITS Acquisition Callback - Timer 2 Period Set */
static void qtm_tmr2_period_set_callback (uint16_t period)
{
    TC1_Timer16bitPeriodSet(period);
}

/* ITS Acquisition Callback - Start Timers */
static void qtm_start_timers_callback (void)
{    
    /* Start Timer 1 */
    TC0_TimerStart();
    
    /* Start Timer 2 */
    TC1_TimerStart();
}

/* ITS Acquisition Callback - Stop Timers */
static void qtm_stop_timers_callback (void)
{
    /* Stop Timer 2 */
    TC1_TimerStop();
    
    /* Stop Timer 1 */
    TC0_TimerStop();
}

/* SW Oversample Process */
static void qtm_oversample_process(void)
{
    touch_ret_t touch_ret = TOUCH_SUCCESS;
    
    /* accumulate samples */
    uint8_t node;
    
    for (node = 0u; node < DEF_NUM_CHANNELS; node++) {
        its_node_accumulated_signals[node].node_acq_signals += its_node_stat1[node].node_acq_signals;
    }

    if (--oversamples > 0u)
    {
        SYSTICK_DelayUs(OVERSAMPLE_DELAY); /* discharge capacitor between samples*/

        DMAC_ChannelResume(DMA_CH_1);
        DMAC_ChannelResume(DMA_CH_2);
        DMAC_ChannelResume(DMA_CH_3);
        
        touch_ret = qtm_its_start_measurement();
        if (touch_ret != TOUCH_SUCCESS)
        {
            qtm_error_callback(0u);
        }
    }
    else
    {
        uint8_t filter, gain;
        for (node = 0u; node < DEF_NUM_CHANNELS; node++)
        {
            filter = its_acq_set_config1.filter_level;
            gain = its_node_config[node].digital_gain;
            if (filter > gain) {filter = filter - gain;}
            else {filter = 0u;}

            its_node_stat1[node].node_acq_signals = \
                    (its_node_accumulated_signals[node].node_acq_signals >> filter);
            its_node_accumulated_signals[node].node_acq_signals = 0u;
        }                    
        /* Set the post-process request flag */
        touch_postprocess_request = 1u;
        
        /* Clear the measurement in progress flag */
        touch_measurement_in_progress = 0u;
    }
}

/* DMA CH2 Callback */
uintptr_t dma_context;
static void qtm_dma_ch2_interrrupt_handler (DMAC_TRANSFER_EVENT event, uintptr_t contextHandle)
{
    switch(event)
    {
        case DMAC_TRANSFER_EVENT_COMPLETE:
            qtm_stop_timers_callback();
            ADC0_Disable();
            qtm_its_discharge_sensors();

            if (its_acq_set_config1.filter_level != 0u)
            {
                /* Set the oversample process request flag */
                oversample_process_request = 1u;
            }
            else
            {
                /* Set the post-process request flag */
                touch_postprocess_request = 1u;
                
                /* Clear the measurement in progress flag */
                touch_measurement_in_progress = 0u;
            }
            
            DMAC_ChannelSuspend(DMA_CH_1);
            DMAC_ChannelSuspend(DMA_CH_2);
            DMAC_ChannelSuspend(DMA_CH_3);
            
            break;
            
        case DMAC_TRANSFER_EVENT_ERROR:
            qtm_error_callback(0u);
            break;
            
        case DMAC_TRANSFER_EVENT_NONE:
            qtm_error_callback(0u);
            break;
    }
}

/*============================================================================
static void qtm_error_callback(uint8_t error)
------------------------------------------------------------------------------
Purpose: this function is used to report error in the modules.
Input  : error code
Output : decoded module error code
Notes  :
Derived Module_error_codes:
    Acquisition module error =1
    post processing module1 error = 2
    post processing module2 error = 3
    ... and so on
============================================================================*/
static void qtm_error_callback(uint8_t error)
{
	module_error_code = error + 1u;

 #if DEF_TOUCH_DATA_STREAMER_ENABLE == 1
 	datastreamer_output();
 #endif
}

/*============================================================================
void touch_init(void)
------------------------------------------------------------------------------
Purpose: Initialization of touch library. PTC, timer, and
         datastreamer modules are initialized in this function.
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_init(void)
{
    qtm_its_set_tmr1_register               ((uint32_t*)&TC1_REGS->COUNT16.TC_CTRLA);
    
    /* Set Peripheral Callback Functions for Acquisition Library */
    qtm_its_set_tmr1_period_set_callback    (qtm_tmr1_period_set_callback);
    qtm_its_set_tmr2_period_set_callback    (qtm_tmr2_period_set_callback);
    qtm_its_set_start_timers_callback       (qtm_start_timers_callback);
    qtm_its_set_stop_timers_callback        (qtm_stop_timers_callback);
    
    qtm_its_init_measurement                (&its_acq_control1);
    
    /* Set DMA CH2 interrupt callback */
    DMAC_ChannelCallbackRegister(DMA_CH_2, qtm_dma_ch2_interrrupt_handler, dma_context);
    
	/* Enable sensor keys and assign nodes */
    uint8_t node;
	for (node = 0u; node < DEF_NUM_CHANNELS; node++) {
		qtm_init_sensor_key(&qtlib_key_set1, node, &its_node_stat1[node]);
    }
    
    touch_timer_config();
}

/*============================================================================
void touch_process(void)
------------------------------------------------------------------------------
Purpose: Main processing function of touch library. This function initiates the
         acquisition, calls post processing after the acquisition complete and
         sets the flag for next measurement based on the sensor status.
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_process(void)
{
    touch_ret_t touch_ret = TOUCH_SUCCESS;
    
    /* Check the oversample_process_request flag for SW Oversampling */
    if (oversample_process_request == 1u) {
        /* Reset the flags for oversample processing */
        oversample_process_request = 0u;
        qtm_oversample_process();
    }
    
    /* Check the touch_postprocess_request flag for Signal Post Processing */
    if (touch_postprocess_request == 1u) {
        /* Reset the flag for node_level_post_processing */
		touch_postprocess_request = 0u;
        
        qtm_its_acquisition_process();
        
        /* key module post-processing */
		touch_ret = qtm_key_sensors_process(&qtlib_key_set1);
        if (touch_ret != TOUCH_SUCCESS) {
            qtm_error_callback(1u);
        }
        
#if (DEF_TOUCH_LOWPOWER_ENABLE == 1u)
        if (0u != (qtlib_key_grp_data_set1.qtm_keys_status & QTM_KEY_DETECT)) {
            /* Something in detect */
            time_since_touch = 0u;
            
            if (measurement_period_store == DEF_TOUCH_LP_MEASUREMENT_PERIOD_MS) {
                /* In low power mode */
                touch_disable_lowpower_measurement();
            }
        }
        else {
            /* Nothing in detect */
            if (measurement_period_store == DEF_TOUCH_MEASUREMENT_PERIOD_MS) {
                /* Not in low power mode */
                if (time_since_touch >= DEF_TOUCH_LOWPOWER_TIMEOUT_MS) {
                    touch_enable_lowpower_measurement();
                }
            }
        }
#endif
        
		/* handle re-burst requests from keys module */
		if ((0u != (qtlib_key_set1.qtm_touch_key_group_data->qtm_keys_status & QTM_KEY_REBURST))) {
			time_to_measure_touch_flag = 1u;
            SYSTICK_DelayUs(OVERSAMPLE_DELAY); /* discharge capacitor between samples*/
		} else {
            measurement_done_touch = 1u;
		}
                
#if DEF_TOUCH_DATA_STREAMER_ENABLE == 1
		datastreamer_output();
#endif
	}
    
	/* Check the time_to_measure_touch_flag flag for Touch Acquisition */
	if ((time_to_measure_touch_flag == 1u) && (touch_measurement_in_progress == 0u)) {
		
		/* Clear the Measure request flag */
		time_to_measure_touch_flag = 0u;
        
        DMAC_ChannelResume(DMA_CH_1);
        DMAC_ChannelResume(DMA_CH_2);
        DMAC_ChannelResume(DMA_CH_3);
        
		/* measure sensors */
        touch_ret = qtm_its_start_measurement();
        if (touch_ret != TOUCH_SUCCESS) {
            qtm_error_callback(0u);
        }
        else
        {
            /* initialize variables for oversampling */
            oversamples = (1u << FILTER_LEVEL);
        
            /* Set the measurement in progress flag */
            touch_measurement_in_progress = 1u;
        }
    }
}

#if (DEF_TOUCH_LOWPOWER_ENABLE == 1u)
/*============================================================================
static void touch_enable_lowpower_measurement(void)
------------------------------------------------------------------------------
Purpose: Adjust measurement period to low power rate
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_enable_lowpower_measurement(void)
{
    RTC_Timer32CounterSet((uint32_t) 0);
    RTC_Timer32CompareSet(DEF_TOUCH_LP_MEASUREMENT_PERIOD_MS);
    
    /* Store the measurement period */
	measurement_period_store = DEF_TOUCH_LP_MEASUREMENT_PERIOD_MS;
}

/*============================================================================
static void touch_disable_lowpower_measurement(void)
------------------------------------------------------------------------------
Purpose: Adjust measurement period to regular rate
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_disable_lowpower_measurement(void)
{
    RTC_Timer32CounterSet((uint32_t) 0);
    RTC_Timer32CompareSet(DEF_TOUCH_MEASUREMENT_PERIOD_MS);
    
	/* Store the measurement period */
	measurement_period_store = DEF_TOUCH_MEASUREMENT_PERIOD_MS;
}
#endif

/*============================================================================
void touch_timer_handler(void)
------------------------------------------------------------------------------
Purpose: This function updates the time elapsed to the touch key module to
         synchronize the internal time counts used by the module.
Input  : none
Output : none
Notes  :
============================================================================*/
uint8_t touch_context = 0;

void touch_timer_handler( RTC_TIMER32_INT_MASK intCause, uintptr_t context )
{
    time_to_measure_touch_flag = 1u;
    
#if (DEF_TOUCH_LOWPOWER_ENABLE == 1u)
    if (time_since_touch < (65535u - measurement_period_store)) {
        time_since_touch += measurement_period_store;
    } else {
        time_since_touch = 65535;
    }
    qtm_update_qtlib_timer(measurement_period_store);
#else
    qtm_update_qtlib_timer(DEF_TOUCH_MEASUREMENT_PERIOD_MS);
#endif
}
uintptr_t rtc_context;

void touch_timer_config(void)
{  
    RTC_Timer32CallbackRegister(touch_timer_handler, rtc_context);
    RTC_Timer32CompareSet((uint32_t) DEF_TOUCH_MEASUREMENT_PERIOD_MS);
    RTC_Timer32Start();
}

uint16_t get_sensor_node_signal(uint16_t sensor_node)
{
    return (its_node_stat1[sensor_node].node_acq_signals);
}

void update_sensor_node_signal(uint16_t sensor_node, uint16_t new_signal)
{
	its_node_stat1[sensor_node].node_acq_signals = new_signal;
}

uint16_t get_sensor_node_reference(uint16_t sensor_node)
{
	return (qtlib_key_data_set1[sensor_node].channel_reference);
}

void update_sensor_node_reference(uint16_t sensor_node, uint16_t new_reference)
{
	qtlib_key_data_set1[sensor_node].channel_reference = new_reference;
}

uint8_t get_sensor_state(uint16_t sensor_node)
{
	return (qtlib_key_set1.qtm_touch_key_data[sensor_node].sensor_state);
}

void update_sensor_state(uint16_t sensor_node, uint8_t new_state)
{
	qtlib_key_set1.qtm_touch_key_data[sensor_node].sensor_state = new_state;
}

#endif /* TOUCH_C */
