/*============================================================================
Filename : qtm_its_auto_acq_samc21_api.h
Project  : Touch Modular Library
Purpose  : Impulse Touch Sensing (ITS) Automated Acquisition for SAMC21 and PIC32CMJH
==============================================================================
(c) 2025 Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.

IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
============================================================================
Version Number : 3.0
Last Updated   : 2025.04.25
Updated By     : Deva Dharshini M
============================================================================
Revision 1.0 - Release build
Revision 1.1 - Bug fix to enable application control of PORT A pins OUT setting
Revision 1.2 - Increase maximum sensor channels to 10
Revision 1.3 - Bug fix to correct swapped sensor signals bug
Revision 1.4 - Update to enable oversampling from application code
Revision 1.5 - Limit pulse width parameter to 125, 250, and 500 nanoseconds
Revision 1.6 - Update structures to support individual gain settings per button
Revision 1.7 - Add support for N variant, minor update for SW oversampling,
                abstract pulse width setting and limit to 2 values
                (i.e., PULSE_SETTING_1, PULSE_SETTING_2)
Revision 1.8 - Add parameter for configuring acquisition frequency
Revision 2.0 - * A fix was added to stop the pulses before starting the ADC measurement.
               * bug fix to correct the signal count difference between standby sleep mode and no sleep mode.
Revision 3.0 - Updated spread spectrum to support upto seven frequencies.
============================================================================*/

#ifndef ITS_ACQ_SAMC21_PIC32CMJH_API_H
#define ITS_ACQ_SAMC21_PIC32CMJH_API_H

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include "qtm_its_common_components_api.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Data Types                                                        */
/* ************************************************************************** */
/* ************************************************************************** */

/* ITS library pulse setting */
typedef enum tag_pulse_setting_t {
    PULSE_SETTING_1,
    PULSE_SETTING_2
} pulse_setting_t;

/* ITS library filter level setting */
typedef enum tag_filter_level_t {
	FILTER_LEVEL_1,
	FILTER_LEVEL_2,
	FILTER_LEVEL_4,
	FILTER_LEVEL_8,
	FILTER_LEVEL_16
} filter_level_t;

/* ITS library digital gain setting */
typedef enum tag_gain_t {
    GAIN_1, GAIN_2, GAIN_4, GAIN_8, GAIN_16
} gain_t;

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Structure Declarations                                            */
/* ************************************************************************** */
/* ************************************************************************** */

typedef struct
{
    uint8_t         sensor_pin;                     /* Selects the sensor pin for this node */
    uint8_t         sample_cap_pin;                 /* Selects the sample cap pin for this node */
    gain_t          digital_gain;                   /* Digital gain (<= acq_set filter_level) */
} its_acq_node_config_t;

typedef struct
{
    uint8_t                 num_channels;           /* Number of sensors (max = 10) */
    its_acq_node_config_t   *node_pins;             /* Node pins array */
    uint16_t                num_pulses;             /* Number of pulses per measurement */
    pulse_setting_t         pulse_setting;          /* Pulse setting for series R tuning */
    uint8_t                 spread_spectrum_enable; /* Spread spectrum acquisition (0: disabled, 1: enabled) */
    filter_level_t          filter_level;           /* Averaging filter level */
    uint8_t                 dma_ch_1;               /* Selects the first DMA channel used by touch lib */
    uint8_t                 dma_ch_2;               /* Selects the second DMA channel used by touch lib */
    uint8_t                 dma_ch_3;               /* Selects the third DMA channel used by touch lib  */
    uint8_t                 num_freq;
    uint16_t               *median_buffer;
    uint8_t                *pulse_times;
} its_acq_set_config_t;

/* Container */
typedef struct
{
    its_acq_set_config_t    *its_acq_node_config;
    its_acq_node_data_t     *its_acq_node_data;
} its_acq_control_t;

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

touch_ret_t qtm_its_init_measurement                (its_acq_control_t *its_acq_control);
touch_ret_t qtm_its_start_measurement               (void);
touch_ret_t qtm_its_acquisition_process             (void);
void        qtm_its_discharge_sensors               (void);

void        qtm_its_set_tmr1_period_set_callback    (void (*tmr1_period_set_callback)   (uint16_t tmr1_period));
void        qtm_its_set_tmr2_period_set_callback    (void (*tmr2_period_set_callback)   (uint16_t tmr2_period));
void        qtm_its_set_start_timers_callback       (void (*start_timers_callback)      (void));
void        qtm_its_set_stop_timers_callback        (void (*stop_timers_callback)       (void));
void        qtm_its_set_tmr1_register               (uint32_t *tmr_reg);
/*============================================================================
uint8_t qtm_get_its_acq_module_ver(void)
------------------------------------------------------------------------------
Purpose: Returns the module Firmware version
Input  : none
Output : Module ID - Upper nibble major / Lower nibble minor 
Notes  : none
============================================================================*/
uint8_t qtm_get_its_acq_module_ver(void);

/*============================================================================
uint16_t qtm_get_its_acq_module_id(void)
------------------------------------------------------------------------------
Purpose: Returns the module id
Input  : none
Output : 16-bit ID
Notes  : none
============================================================================*/
uint16_t qtm_get_its_acq_module_id(void);

/* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* ITS_ACQ_SAMC21_PIC32CMJH_API_H */

/* *****************************************************************************
 End of File
 */