// MIT License
//
// Copyright(c) 2021 Giovanni Bertazzoni <nottheworstdev@gmail.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files(the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions :
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//last edit 14.05.2025 by Zell
//1206, 3216 fonts not working!

#include <stdbool.h>
#include <string.h>
#include <xc.h>

#include "JDI_MIP_Display2.h"
#include "oledfont.h"
#include "font16x32.h"
#include "peripheral/port/plib_port.h"
#include "peripheral/sercom/spi_master/plib_sercom5_spi_master.h"
//#include "../mcc_generated_files/system/pins.h"

//extern uint16_t _background;

//external fonts
extern const unsigned char asc2_1608[][16]; //not working!
extern const unsigned char asc2_1206[][12]; //seems working ,   ascii_1206 not working!
extern const unsigned char asc2_0806[][6]; // working properly! 
//extern const char font16x32[128][64]; //seems not working properly! 
extern const unsigned char asc2_3216[95][64]; //seems not working properly! 



uint16_t _background = COLOR_BLACK;
char _backBuffer[(JDI_DISPLAY_Width / 2) * JDI_DISPLAY_Height];  //image buffer

uint8_t SPI_txBuffer[2];

//#ifdef USE_ESP32_DMA
//    #include "driver/spi_master.h"
//    spi_device_handle_t dmaHAL; // DMA SPA??
//    spi_host_device_t spi_host = (spi_host_device_t)1; // ????????
//#endif

//JDI_MIP_Display::JDI_MIP_Display() : Adafruit_GFX(DISPLAY_WIDTH, DISPLAY_HEIGHT), _pSPIx(&SPI), _spi_settings(SPI_FREQUENCY, MSBFIRST, SPI_MODE0)
//{
//    _mosi = PIN_MOSI;
//    _miso = PIN_MISO;
//    _sck = PIN_SCK;
//    _scs = PIN_SCS;
//    _disp = PIN_DISP;  reset pin in MikroBus adapter board
//    _freq = SPI_FREQUENCY;
//    _frontlight = PIN_FRONTLIGHT;
//}
//
//void JDI_MIP_Display::selectSPI(SPIClass& spi, SPISettings spi_settings)
//{
//  _pSPIx = &spi;
//  _spi_settings = spi_settings;
//}

//void JDI_MIP_Display::begin()
//{
//    _background = COLOR_BLACK;
//    digitalWrite(_scs, LOW);
//    pinMode(_scs, OUTPUT);
//    pinMode(_disp, OUTPUT);
//    pinMode(_frontlight, OUTPUT);
//    memset(&_backBuffer[0], (char)((_background & 0x0F) | ((_background & 0x0F) << 4)), sizeof(_backBuffer));
//#ifdef DIFF_LINE_UPDATE
//    memset(&_dispBuffer[0], (char)((_background & 0x0F) | ((_background & 0x0F) << 4)), sizeof(_dispBuffer));
//#endif
//
//    // ????DMA Is DMA enabled
//#ifdef USE_ESP32_DMA
//    initDMA(_sck, _miso, _mosi, _scs, _freq); 
//#else
//    _pSPIx->begin();
//#endif
//}

void JDI_Display_init() {
    _background = COLOR_BLACK;
    PB00_CS_Clear();
    // digitalWrite(_scs, LOW);
    //    pinMode(_scs, OUTPUT);
    //    pinMode(_disp, OUTPUT);
    //    pinMode(_frontlight, OUTPUT);
    memset(&_backBuffer[0], (char) ((_background & 0x0F) | ((_background & 0x0F) << 4)), sizeof (_backBuffer));
#ifdef DIFF_LINE_UPDATE
    memset(&_dispBuffer[0], (char) ((_background & 0x0F) | ((_background & 0x0F) << 4)), sizeof (_dispBuffer));
#endif



}

void JDI_Display_refresh() {

    // PB00_CS_Set();
    for (int i = 0; i < JDI_DISPLAY_Height; i++) {
        int line_Pixel_Idx = HALF_WIDTH * i;
        char *line_data;
#ifdef DIFF_LINE_UPDATE
        if (JDI_Display_compareBuffersLine(lineIdx) == true) continue;
        memcpy(&_dispBuffer[lineIdx], &_backBuffer[lineIdx], HALF_WIDTH);
        line_cmd = &_dispBuffer[lineIdx];
#else
        line_data = &_backBuffer[line_Pixel_Idx];
#endif
        JDI_Display_sendLineCommand(line_data, i); //refresh line by line
    }
    //  PB00_CS_Clear();

}

void JDI_Display_refresh_line(int line_idx) {

    if ((line_idx < 0) || (line_idx >= JDI_DISPLAY_Height)) {
        return;
    }

    //PB00_CS_Set();

    int line_Pixel_Idx = HALF_WIDTH * line_idx;
    char *line_data;

    line_data = &_backBuffer[line_Pixel_Idx];

    JDI_Display_sendLineCommand(line_data, line_idx); //refresh line by line

    _nop();
    //PB00_CS_Clear();

}

bool JDI_Display_compareBuffersLine(int lineIndex) {
#ifdef DIFF_LINE_UPDATE
    for (int i = 0; i < HALF_WIDTH; i++) {
        int pixelIdx = lineIndex + i;
        if (_backBuffer[pixelIdx] != _dispBuffer[pixelIdx])
            return false;
    }
#endif
    return true;
}

void JDI_Display_BlinkWhite() {

    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_BLINKING_WHITE;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, sizeof (SPI_txBuffer));
    //    while (true == SERCOM5_SPI_IsTransmitterBusy()) {
    //        _nop(); //Wait here till the transfer is done.
    //    }


    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }
    _nop();
    PB00_CS_Clear();
}

void JDI_Display_BlinkBlack() {

    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_BLINKING_BLACK;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, sizeof (SPI_txBuffer));
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }


    //    while (SERCOM5_SPI_IsBusy() == true) {
    //         _nop();//Wait here till the transfer is done.
    //    }
    _nop();
    PB00_CS_Clear();
}

//CMD_NO_BLINK

void JDI_Display_BlinkOFF() {

    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_NO_BLINK;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, sizeof (SPI_txBuffer));
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }


    //    while (SERCOM5_SPI_IsBusy() == true) {
    //         _nop();//Wait here till the transfer is done.
    //    }
    _nop();
    PB00_CS_Clear();

}

//CMD_BLINKING_INVERSION

void JDI_Display_INVERSION() {

    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_BLINKING_INVERSION;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, sizeof (SPI_txBuffer));
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }


    //    while (SERCOM5_SPI_IsBusy() == true) {
    //         _nop();//Wait here till the transfer is done.
    //    }
    _nop();
    PB00_CS_Clear();

}

void JDI_Display_clearScreen() {

    memset(&_backBuffer[0], (char) ((_background & 0x0F) | ((_background & 0x0F) << 4)), sizeof (_backBuffer));
    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_ALL_CLEAR;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, 2);
    //    while (SERCOM5_SPI_IsBusy() == true) {
    //        _nop(); //Wait here till the transfer is done.
    //    }
    _nop();
    PB00_CS_Clear();


    //-----------SPI ------------
    //        _pSPIx->beginTransaction(_spi_settings);
    //        digitalWrite(_scs, HIGH);
    //        _pSPIx->transfer(CMD_ALL_CLEAR);
    //        _pSPIx->transfer(0x00);
    //        digitalWrite(_scs, LOW);
    //        _pSPIx->endTransaction();
    //#ifdef USE_ESP32_DMA
    //    }
    //#endif
}

//send one line

void JDI_Display_sendLineCommand(char *line_cmd, int line) {
    if ((line < 0) || (line >= JDI_DISPLAY_Height)) {
        return;
    }
    //CMD_UPDATE

    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_UPDATE;
    SPI_txBuffer[1] = line + 1;
    SERCOM5_SPI_Write(&SPI_txBuffer[0], 1);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //
    }
    SERCOM5_SPI_Write(&SPI_txBuffer[1], 1);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //
    }
    //    SERCOM5_SPI_Write(SPI_txBuffer, sizeof (SPI_txBuffer));
    //    while (SERCOM5_SPI_IsBusy() == true) {
    //        _nop(); //stuck here !! Wait here till the transfer is done.
    //    }
    //SERCOM5_SPI_Write(line_cmd,HALF_WIDTH);//need test!
    for (int i = 0; i < HALF_WIDTH; i++) {
        SERCOM5_SPI_Write(&line_cmd[i], 1);
        while (SERCOM5_SPI_IsBusy() == true) {
            _nop(); //stuck here !! Wait here till the transfer is done.
        }
        _nop();

    }
    SPI_txBuffer[0] = 0x00;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, 2);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }
    SERCOM5_SPI_Write(SPI_txBuffer, 1);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }
    // PB00_CS_Set();
    _nop();

    PB00_CS_Clear();

    //----------SPI transfer
    //        _pSPIx->beginTransaction(_spi_settings);
    //        digitalWrite(_scs, HIGH);
    //        _pSPIx->transfer(CMD_UPDATE);
    //        _pSPIx->transfer(line + 1);
    //
    //        for(int i = 0; i < HALF_WIDTH; i++){
    //            _pSPIx->transfer(line_cmd[i]);
    //        }
    //
    //        _pSPIx->transfer(0x00);
    //        _pSPIx->transfer(0x00);
    //        digitalWrite(_scs, LOW);
    //        _pSPIx->endTransaction();
    //#ifdef USE_ESP32_DMA
    //    }
    //#endif
}

void JDI_Display_refresh_testline(int line_idx) {

    if ((line_idx < 0) || (line_idx >= JDI_DISPLAY_Height)) {
        return;
    }

    //PB00_CS_Set();
    //line_idx = 0;

    int line_Pixel_Idx = HALF_WIDTH * line_idx;
    char *line_data;

    line_data = &_backBuffer[line_Pixel_Idx];

    JDI_Display_sendLinetest(line_data, line_idx); //refresh line by line

    _nop();
    //PB00_CS_Clear();

}

void JDI_Display_sendLinetest(char *line_cmd, int line) {
    if ((line < 0) || (line >= JDI_DISPLAY_Height)) {
        return;
    }
    //CMD_UPDATE
    //line = 0;
    PB00_CS_Set();
    SPI_txBuffer[0] = CMD_UPDATE;
    SPI_txBuffer[1] = line + 1;
    SERCOM5_SPI_Write(&SPI_txBuffer[0], 1);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //
    }
    SERCOM5_SPI_Write(&SPI_txBuffer[1], 1);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //
    }
    //SERCOM5_SPI_Write(SPI_txBuffer, sizeof(SPI_txBuffer));

    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //
    }

    for (int i = 0; i < HALF_WIDTH; i++) {
        SERCOM5_SPI_Write(&line_cmd[i], 1);
        while (SERCOM5_SPI_IsBusy() == true) {
            _nop(); //stuck here !! Wait here till the transfer is done.
        }
        _nop();

    }


    SPI_txBuffer[0] = 0x00;
    SPI_txBuffer[1] = 0x00;
    SERCOM5_SPI_Write(SPI_txBuffer, 2);
    while (SERCOM5_SPI_IsBusy() == true) {
        _nop(); //stuck here !! Wait here till the transfer is done.
    }
    line = 0;

    PB00_CS_Set();
    PB00_CS_Clear();

}

void JDI_Display_drawBufferedPixel(int16_t x, int16_t y, uint16_t color) {
    JDI_Display_drawPixel(x, y, color); // 
}

void JDI_Display_drawPixel(int16_t x, int16_t y, uint16_t color) {
    if (x < 0 || x >= JDI_DISPLAY_Width || y < 0 || y >= JDI_DISPLAY_Height) {
        return;
    }

    int pixelIdx = ((JDI_DISPLAY_Width / 2) * y) + (x / 2);

    if (x % 2 == 0) {
        _backBuffer[pixelIdx] &= 0x0F;
        _backBuffer[pixelIdx] |= (color & 0x0F) << 4;
    } else {
        //lower 4bits
        _backBuffer[pixelIdx] &= 0xF0;
        _backBuffer[pixelIdx] |= color & 0x0F;
    }
}

void JDI_Display_setBackgroundColor(uint16_t color) {
    _background = color;
}

void JDI_Display_displayOn() { //tested works!
    //SPI_RST_RB6_SetHigh();
    SPI_RST_PB04_Set();
    //digitalWrite(_disp, HIGH);
}

void JDI_Display_displayOff() {
    //SPI_RST_RB6_SetLow();
    SPI_RST_PB04_Clear();
    //digitalWrite(_disp, LOW);
}

void JDI_Display_frontlightOn() {
    //digitalWrite(_frontlight, HIGH);
}

void JDI_Display_frontlightOff() {
    //digitalWrite(_frontlight, LOW);
}

//font asc2_0806 asc2_1608 asc2_3216 works, tested! 2025.5.14
void JDI_Display_drawChar(uint16_t x, uint16_t y, uint8_t num, uint16_t fc, uint16_t bc, uint8_t sizey, uint8_t mode) {
    uint8_t temp, sizex, t, m = 0;
    uint16_t i, TypefaceNum; //??????????
    uint16_t x0 = x;
    uint16_t y0 = y;
    if (sizey == 8){
        sizex = 6;
        TypefaceNum = 6;
    }
    else {
        sizex = sizey / 2;
    TypefaceNum = (sizey / 8 + ((sizey % 8) ? 1 : 0)) * sizex; //??????????????, correct!
    }
    //TypefaceNum = (sizex / 8 + ((sizex % 8) ? 1 : 0)) * sizey; //??????????????,not correct!
    num = num - ' '; //?? ASCII ??? 32 ???????????????????????????????
    //LCD_Address_Set(x, y, x + sizex - 1, y + sizey - 1); //?????? 
    for (i = 0; i < TypefaceNum; i++) {
        if (sizey == 8) {
            temp = asc2_0806[num][i];
        }//??0806??
        else if (sizey == 12)temp = asc2_1206[num][i]; //??6x12??
        else if (sizey == 16)temp = asc2_1608[num][i]; //??8x16??
            //else if(sizey==24)temp=asc2_2412[num][i];		 //??12x24??
        else if (sizey == 32)temp = asc2_3216[num][i]; //??16x32??
        else return;
        for (t = 0; t < 8; t++) {
            if (!mode)//non-overlapping mode
            {
                if (temp & (0x01 << t))
                    //LCD_WR_DATA(fc);
                    JDI_Display_drawPixel(x, y, fc);
                else
                    //LCD_WR_DATA(bc); //draw background color
                    JDI_Display_drawPixel(x, y, bc);
                m++;
                if (m % sizex == 0) {
                    m = 0;
                    break;
                }
            }
            else//overlapping mode
            {
                
                   if (temp & (0x01 << t))
                   JDI_Display_drawPixel(x, y, fc);
                //                if (temp & (0x01 << t))
                //                    LCD_DrawPoint(x, y, fc); //draw one point
                //                x++;
                //                if ((x - x0) == sizex) {
                //                    x = x0;
                //                    y++;
                //                    break;
                //                }
            }
            y++;
        }

        x++;
        y = y0;
        if ((sizey != 8)&&((x - x0) == sizey / 2)) {
            x = x0;
            y0 = y0 + 8;
        }
    }
}


//void JDI_MIP_Display::drawPixel(int16_t x, int16_t y, uint16_t color)
//{
//    if(x < 0 || x >= width() || y < 0 || y >= height()){
//        return;
//    }
//
//    int pixelIdx = ((width() / 2) * y) + (x / 2);
//
//    if(x % 2 == 0){
//        _backBuffer[pixelIdx] &= 0x0F;
//        _backBuffer[pixelIdx] |= (color & 0x0F) << 4;
//    }
//    else{
//        _backBuffer[pixelIdx] &= 0xF0;
//        _backBuffer[pixelIdx] |= color & 0x0F;
//    }
//}
//
//void JDI_MIP_Display::setBackgroundColor(uint16_t color)
//{
//    _background = color;
//}
//
//void JDI_MIP_Display::displayOn()
//{
//    digitalWrite(_disp, HIGH);
//}
//
//void JDI_MIP_Display::displayOff()
//{
//    digitalWrite(_disp, LOW);
//}
//
//void JDI_MIP_Display::frontlightOn()
//{
//    digitalWrite(_frontlight, HIGH);
//}
//
//void JDI_MIP_Display::frontlightOff()
//{
//    digitalWrite(_frontlight, LOW);
//}
//#ifdef USE_ESP32_DMA
/***************************************************************************************
 ** ?????dmaBusy            Function name: dmaBusy
 ** ?????DMA????         Description: Check if DMA is busy
 ***************************************************************************************/
//bool JDI_MIP_Display::dmaBusy(void)
//{
//  if (!DMA_Enabled || !spiBusyCheck) return false;
//
//  spi_transaction_t *rtrans;
//  esp_err_t ret;
//  uint8_t checks = spiBusyCheck;
//  for (int i = 0; i < checks; ++i)
//  {
//    ret = spi_device_get_trans_result(dmaHAL, &rtrans, 0);
//    if (ret == ESP_OK) spiBusyCheck--;
//  }
//
//  // Serial.print("spiBusyCheck=");Serial.println(spiBusyCheck);
//  if (spiBusyCheck == 0)  return false;
//  return true;
//}
//
///***************************************************************************************
//**?????dmaWait          Function name: dmaWait
//**?????DMA???????  Description: Waiting for DMA to end (blocking!)
//***************************************************************************************/
//void JDI_MIP_Display::dmaWait(void)
//{
//  if (!DMA_Enabled || !spiBusyCheck)  return;
//  spi_transaction_t *rtrans;
//  esp_err_t ret;
//  for (int i = 0; i < spiBusyCheck; ++i)
//  {
//    ret = spi_device_get_trans_result(dmaHAL, &rtrans, portMAX_DELAY);
//    assert(ret == ESP_OK);
//  }
//  spiBusyCheck = 0;
//}
//
///***************************************************************************************
//** ?????pushPixelsDMA                  Function name: pushPixelsDMA
//** ?????????TFT?len????32767?  Explanation: Push pixels to TFT (len must be less than 32767)
//***************************************************************************************/
//void JDI_MIP_Display::pushPixelsDMA(uint8_t *image, uint32_t len)
//{
//    _pushPixelsDMA(image, len);
//}
//void JDI_MIP_Display::_pushPixelsDMA(uint8_t *image, uint32_t len)
//{
//    if ((len == 0) || (!DMA_Enabled)) return;
//
//    dmaWait();
//
//    /*if (_swapBytes)
//    {
//      for (uint32_t i = 0; i < len; i++)
//        (image[i] = image[i] << 8 | image[i] >> 8);
//    }*/
//
//    esp_err_t ret;
//    static spi_transaction_t trans;
//
//    memset(&trans, 0, sizeof(spi_transaction_t));
//
//    trans.user = (void *)1;
//    trans.tx_buffer = image; // ????
//    trans.length = len * 8;  // ?????????? uint8_t = 8bit uint16_t = 16bit
//    trans.flags = 0;         // SPI_TRANS_USE_TXDATA??
//    trans.rx_buffer = NULL;  // ????????????NULL???MISO???????DMA???4????????
//
//    ret = spi_device_queue_trans(dmaHAL, &trans, portMAX_DELAY);
//    assert(ret == ESP_OK);
//    // Serial.print("ret:"); Serial.println(ret);
//    spiBusyCheck++;
//}
//
///***************************************************************************************
//** ?????initDMA                            Function name: initDMA
//** ??????DMA??-??????????true   Description: Initialize DMA engine - returns true if initialization is normal
//***************************************************************************************/
//bool JDI_MIP_Display::initDMA(int sck, int miso, int mosi, int ss, int fre)
//{
//    if (DMA_Enabled) return false;
//
//    /*Serial.print("sck:"); Serial.println(sck);
//    Serial.print("miso:"); Serial.println(miso);
//    Serial.print("mosi:"); Serial.println(mosi);
//    Serial.print("ss:"); Serial.println(ss);
//    Serial.print("fre:"); Serial.println(fre);*/
//
//    esp_err_t ret;
//    // ??spi_bus_config_t???????????????????
//    spi_bus_config_t buscfg = {
//        .mosi_io_num = mosi,
//        .miso_io_num = miso,
//        .sclk_io_num = sck,
//        .quadwp_io_num = -1,
//        .quadhd_io_num = -1,
//        .data4_io_num = -1,
//        .data5_io_num = -1,
//        .data6_io_num = -1,
//        .data7_io_num = -1,
//        .max_transfer_sz = 1024, // TFT???? DISPLAY_WIDTH * DISPLAY_HEIGHT * 2 + 8
//        .flags = 0,
//        .intr_flags = 0};
//
//    // ???????cs??
//    int8_t pin = -1;
//    if (ss) pin = ss;
//
//    // ???SPI??????
//    spi_device_interface_config_t devcfg = {
//        .command_bits = 0, // ????
//        .address_bits = 0, // ????
//        .dummy_bits = 0,
//        .mode = SPI_MODE0, // ??
//        .duty_cycle_pos = 0,
//        .cs_ena_pretrans = 0,
//        .cs_ena_posttrans = 0,
//        .clock_speed_hz = fre, // ??
//        .input_delay_ns = 0,
//        .spics_io_num = pin,
//        .flags = SPI_DEVICE_POSITIVE_CS, // 0, SPI_DEVICE_NO_DUMMY
//        .queue_size = 2,
//        .pre_cb = 0, // dc_callback?//????D/C?
//        .post_cb = 0};
//
//    // spi????? esp32c3??auto DMA ??
//    ret = spi_bus_initialize(spi_host, &buscfg, SPI_DMA_CH_AUTO);
//    ESP_ERROR_CHECK(ret);
//    // Serial.print("ret0:"); Serial.println(ret);
//    ret = spi_bus_add_device(spi_host, &devcfg, &dmaHAL); // spi??????
//    ESP_ERROR_CHECK(ret);
//    // Serial.print("ret1:"); Serial.println(ret);
//
//    DMA_Enabled = true;
//    spiBusyCheck = 0;
//    return true;
//}
//
///***************************************************************************************
//** ?????deInitDMA          Function name: deInitDMA
//** ?????DMA???SPI???  Description: Disconnect the DMA engine from SPI
//***************************************************************************************/
//void JDI_MIP_Display::deInitDMA(void)
//{
//  if (!DMA_Enabled) return;
//  spi_bus_remove_device(dmaHAL); // spi??????
//  spi_bus_free(spi_host);        // spi????
//  DMA_Enabled = false;
//}
//#endif