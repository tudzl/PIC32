/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
void enter_sleep_mode(void);
int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    enter_sleep_mode();
    PM_IdleModeEnter();
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}



// Function to enter Sleep mode on PIC32CM6408PL028
void enter_sleep_mode(void)
{
    // Ensure all interrupts are disabled before entering sleep
   // __builtin_disable_interrupts();
    NVIC_INT_Disable();

    // Set the SLEEP bit in the SCR register to enter sleep mode
    // The System Control Register (SCR) is part of the ARM Cortex-M0+ core
    SCB->SCR &= ~SCB_SCR_SEVONPEND_Msk; // Optional: clear SEVONPEND
    SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk; // Ensure SLEEPDEEP is cleared for normal sleep

    // Execute WFI (Wait For Interrupt) instruction to enter sleep mode
    __WFI();

    // Re-enable interrupts after waking up
    //__builtin_enable_interrupts();
    NVIC_INT_Enable();
}

/*******************************************************************************
 End of File
*/

