#include "qtm_its_touch_key_api.h"

#define QTM_MODULE_VERSION 0x13

/* Variables */
/* Internal timing management */
uint16_t qtm_local_ms_timecount = 0u;

touch_ret_t qtm_init_sensor_key(qtm_touch_key_control_t *qtm_lib_key_group_ptr, uint8_t which_sensor_key, its_acq_node_data_t *acq_lib_node_ptr)
{
	touch_ret_t touch_return_thing = TOUCH_SUCCESS;

	if ((NULL == qtm_lib_key_group_ptr) || (NULL == acq_lib_node_ptr))
	{
		touch_return_thing = TOUCH_INVALID_POINTER;
	}
	else
	{
		/* Configure key */
		qtm_lib_key_group_ptr->qtm_touch_key_data[which_sensor_key].sensor_state = QTM_KEY_STATE_INIT;

		/* Set pointers to node status and signal */
		qtm_lib_key_group_ptr->qtm_touch_key_data[which_sensor_key].node_data_struct_ptr = acq_lib_node_ptr;
	}

	return touch_return_thing;
}

/*============================================================================
void qtm_update_qtlib_timer(uint16_t time_elapsed_since_update)
------------------------------------------------------------------------------
Purpose: Updates local variable with time period
Input  : Number of ms since last update
Output : none
Notes  : none
============================================================================*/
void qtm_update_qtlib_timer(uint16_t time_elapsed_since_update)
{
	/* Allow rollover */
	qtm_local_ms_timecount += time_elapsed_since_update;
}

/*============================================================================
static void qtm_timed_feature_process(qtm_touch_key_control_t* qtm_lib_key_group_ptr);
------------------------------------------------------------------------------
Purpose: Implements drift / recal features based on 200ms timer
Input  : Pointer to key group control data
Output : none
Notes  : none
============================================================================*/
static void qtm_timed_feature_process(qtm_touch_key_control_t *qtm_lib_key_group_ptr)
{
	uint16_t key_counterz, other_key_counterz;
	uint16_t crossed_timebase = 0u;
	uint16_t local_timecount_copy;
	uint8_t this_key_aks_group = 0u;


	/* Copy the timestamp, it could be updated in a higher priority ISR */
	local_timecount_copy = qtm_local_ms_timecount;

	if (local_timecount_copy > (qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp + QTLIB_TIMEBASE))
	{
		/* Time period has passed */
		crossed_timebase = local_timecount_copy - qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp;
	}
	else if (local_timecount_copy < qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp)
	{
		/* Rollover */
		if (((0xFFFFu - qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp) + local_timecount_copy) > QTLIB_TIMEBASE)
		{
			/* Time period has passed */
			crossed_timebase = ((0xFFFFu - qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp) + local_timecount_copy);
		}
	}
	else
	{
		/* Time period has not passed */
	}

	/* Update counters + drift if appropriate */
	while (crossed_timebase > QTLIB_TIMEBASE)
	{
		/* Cycle through once per time period */
		crossed_timebase -= QTLIB_TIMEBASE;

		/* Update key group timestamp (Allow it to rollover) */
		qtm_lib_key_group_ptr->qtm_touch_key_group_data->acq_group_timestamp += QTLIB_TIMEBASE;

		if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_data->dht_count_in)
		{
			/* Drift hold = 0 -> Decrement drift counters */
			if (0u < qtm_lib_key_group_ptr->qtm_touch_key_group_data->tch_drift_count_in)
			{
				/* Count down */
				qtm_lib_key_group_ptr->qtm_touch_key_group_data->tch_drift_count_in--;
			}

			if (0u < qtm_lib_key_group_ptr->qtm_touch_key_group_data->antitch_drift_count_in)
			{
				/* Count down */
				qtm_lib_key_group_ptr->qtm_touch_key_group_data->antitch_drift_count_in--;
			}

			/* Towards touch drift */
			if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_touch_drift_rate)
			{
				/* Towards touch drift disabled */
			}
			else
			{
				if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_data->tch_drift_count_in)
				{
					for (key_counterz = 0u; key_counterz < qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors; key_counterz++)
					{
						/* Keys in NO_DETECT or qtm_KEY_STATE_SUSPEND only - Suspended keys may have been measured during the drift period */
						if ((QTM_KEY_STATE_NO_DET == qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state) || (QTM_KEY_STATE_SUSPEND == qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state))
						{
							if (qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference < qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].node_data_struct_ptr->node_acq_signals)
							{
								uint8_t drift_step = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_drift_step;
								if (drift_step == 0u)
								{
									/* drift step set to 0, so just drift at normal rate (1) */
									qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference++;
								}
								else
								{
									/* drift step greater than zero*/
//									if (drift_step > 10u)
//									{
//										/* drift step greater than maximum rate (10), so set to 10 */
//										drift_step = 10u;
//									}
									uint16_t diff = qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].node_data_struct_ptr->node_acq_signals - qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference;
									if (diff < drift_step)
									{
										/* difference between signal and reference is less than the drift step setting, so only drift the amount of the difference */
										qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference += diff;
									}
									else
									{
										/* difference between signal and reference is greater than the drift step setting, so drift by the step setting */
										qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference += drift_step;
									}
								}
							}
						}
					}
					/* Reload towards-touch drift time */
					qtm_lib_key_group_ptr->qtm_touch_key_group_data->tch_drift_count_in = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_touch_drift_rate;
				}
			}

			/* Away from touch drift */
			if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_drift_rate)
			{
				/* Away from touch drift disabled */
			}
			else
			{
				if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_data->antitch_drift_count_in)
				{
					for (key_counterz = 0u; key_counterz < qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors; key_counterz++)
					{
						/* Keys in NO_DETECT or qtm_KEY_STATE_SUSPEND only - Suspended keys may have been measured during the drift period */
						if ((QTM_KEY_STATE_NO_DET == qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state) || (QTM_KEY_STATE_SUSPEND == qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state))
						{
							if (qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference > qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].node_data_struct_ptr->node_acq_signals)
							{
								uint8_t drift_step = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_drift_step;
								if (drift_step == 0u)
								{
									/* drift step set to 0, so just drift at normal rate (1) */
									qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference--;
								}
								else
								{
									/* drift step greater than zero*/
//									if (drift_step > 10u)
//									{
//										/* drift step greater than maximum rate (10), so set to 10 */
//										drift_step = 10u;
//									}
									uint16_t diff = qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference - qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].node_data_struct_ptr->node_acq_signals;
									if (diff < drift_step)
									{
										/* difference between signal and reference is less than the drift step setting, so only drift the amount of the difference */
										qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference -= diff;
									}
									else
									{
										/* difference between signal and reference is greater than the drift step setting, so drift by the step setting */
										qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].channel_reference -= drift_step;
									}
								}
							}
						}
					}
					/* Reload anti-touch drift time */
					qtm_lib_key_group_ptr->qtm_touch_key_group_data->antitch_drift_count_in = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_drift_rate;
				}
			}
		}
		else
		{
			/* Drift Hold */
			qtm_lib_key_group_ptr->qtm_touch_key_group_data->dht_count_in--;
		}

		/* Max On Duration */
		if (0u == qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_max_on_time)
		{
			/* MOD Disabled */
		}
		else
		{
			for (key_counterz = 0u; key_counterz < qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors; key_counterz++)
			{
				/* Keys in DETECT only */
				if (QTM_KEY_STATE_DETECT == qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state)
				{
					if (qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state_counter > 0u)
					{
						qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state_counter--;
					}
					else
					{
						/* Recalibrate */
						qtm_lib_key_group_ptr->qtm_touch_key_data[key_counterz].sensor_state = QTM_KEY_STATE_INIT;

						/* And all other nodes / keys in the same AKS group */
						this_key_aks_group = (qtm_lib_key_group_ptr->qtm_touch_key_config[key_counterz].channel_aks_group);
						if(0u == this_key_aks_group)
						{
							/* No AKS enabled for this key */
						}
						else
						{							  
							for(other_key_counterz = 0u; other_key_counterz < qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors; other_key_counterz++)
							{
								if(this_key_aks_group == (qtm_lib_key_group_ptr->qtm_touch_key_config[other_key_counterz].channel_aks_group))
								{
									/* Same AKS Group -> Also recalibrate */
									qtm_lib_key_group_ptr->qtm_touch_key_data[other_key_counterz].sensor_state = QTM_KEY_STATE_INIT;					
								}					
								else
								{
									/* Different AKS group */
								}
							}
						}
					} /* Recalibrate */
				}/* Detect */
			}/* Count through keys */
		}/* Max On Not disabled */
	}/* Timebase loops */
}

/*============================================================================
static uint8_t check_for_aks_block(qtm_touch_key_control_t* qtm_lib_key_group_ptr, uint16_t which_sensor_key)
------------------------------------------------------------------------------
Purpose: Checks if a key is blocked from DETECT by AKS
Input  : Pointer to key group control, sensor key to check
Output : 0 = not blocked, 1 = blocked
Notes  : none
============================================================================*/
static uint8_t check_for_aks_block(qtm_touch_key_control_t* qtm_lib_key_group_ptr, uint16_t which_sensor_key)
{
uint16_t count_through_all;
uint16_t surplus_delta_this_key;
uint16_t surplus_delta_check_key;
uint8_t this_key_aks_group;
uint8_t this_key_aks_blocked = 0u;

this_key_aks_group = qtm_lib_key_group_ptr->qtm_touch_key_config[which_sensor_key].channel_aks_group;
surplus_delta_this_key = (qtm_lib_key_group_ptr->qtm_touch_key_data[which_sensor_key].node_data_struct_ptr->node_acq_signals) - (qtm_lib_key_group_ptr->qtm_touch_key_data[which_sensor_key].channel_reference);
surplus_delta_this_key -= qtm_lib_key_group_ptr->qtm_touch_key_config[which_sensor_key].channel_threshold;

/* Look for other keys which may block this one */
for (count_through_all = 0u; count_through_all < (qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors); count_through_all++)
{
	if(count_through_all == which_sensor_key)
	{
		/* Don't check against itself */
	}
	else
	{
		if (qtm_lib_key_group_ptr->qtm_touch_key_config[count_through_all].channel_aks_group == this_key_aks_group)
		{
			/* Same AKS Group -> Check if the key is already in detect */
			if ((qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].sensor_state == QTM_KEY_STATE_DETECT)||(qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].sensor_state == QTM_KEY_STATE_FILT_OUT))
			{
				/* Blocked */
				this_key_aks_blocked = 1u;
			}
			/* Otherwise compare (delta-threshold) */
			else if ((qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].channel_reference) < (qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].node_data_struct_ptr->node_acq_signals))
			{
				/* Towards touch delta */
				surplus_delta_check_key = (qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].node_data_struct_ptr->node_acq_signals) - (qtm_lib_key_group_ptr->qtm_touch_key_data[count_through_all].channel_reference);
				if (surplus_delta_check_key > qtm_lib_key_group_ptr->qtm_touch_key_config[count_through_all].channel_threshold)
				{
					/* Delta for check key exceeds threshold */
					surplus_delta_check_key -= qtm_lib_key_group_ptr->qtm_touch_key_config[count_through_all].channel_threshold;
					if (surplus_delta_check_key > surplus_delta_this_key)
					{
						/* Blocked */
						this_key_aks_blocked = 1u;
					}            
				}
			}
			else
			{
				/* Not blocked */
			}               
			
			if (0u == this_key_aks_blocked)
			{
				/* Do nothing */
			}
			else
			{
				/* Exit the loop when a blocking key is found */
				break;
			}            
		} /* Same AKS Group */      
	}
} /* for (...) */

return this_key_aks_blocked;
}

touch_ret_t qtm_key_sensors_process(qtm_touch_key_control_t *qtm_lib_key_group_ptr)
{
	uint8_t reburst_required = 0u;
	uint8_t keys_status_temp = 0u;
	uint16_t num_sensor_keys;
	uint16_t touch_delta;
	uint8_t node_cal_state, aks_blocked;
	uint8_t this_key_current_state;

	touch_ret_t touch_return_thing = TOUCH_SUCCESS;

	if (NULL == qtm_lib_key_group_ptr)
	{
		touch_return_thing = TOUCH_INVALID_POINTER;
	}
	else
	{
		for (num_sensor_keys = 0u; num_sensor_keys < qtm_lib_key_group_ptr->qtm_touch_key_group_config->num_key_sensors; num_sensor_keys++)
		{
			this_key_current_state = qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state;
			switch (this_key_current_state)
			{
				case (QTM_KEY_STATE_INIT):
				{
					qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals);
					qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
				}
				break;
				case (QTM_KEY_STATE_NO_DET):
				{
					if (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference == qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals)
					{
						/* Reference = Signal -> No Action */
					}
					else if (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference > qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals)
					{
						/* Reference > Signal -> Anti-touch? */
						touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference - qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals);
						if (touch_delta < (uint8_t)((qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold) >> qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_recal_thr))
						{
							/* Delta is less than anti-touch threshold */
						}
						else
						{
							/* Delta is greater than anti-touch threhsold */
							if (0u == (qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_di))
							{
								/* Anti-touch recalibration disabled */
							}
							else
							{
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_ANTI_TCH;
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = (uint16_t)qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_di;
								reburst_required = 1u;
							}
						}
					}
					else
					{
						/* Reference < Signal -> Touch? */
						touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals - qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference);
						if (touch_delta < (uint8_t)(qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold))
						{
							/* Delta is less than touch threshold */
						}
						else
						{
							/* Delta is greater than touch threshold */
							/* AKS Block ? - Any key in same AKS group either In Detect or (Delta - Threshold) > (This Delta - This Threshold) */
							if(0u == qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_aks_group)
							{
							aks_blocked = 0u;
							}
							else
							{
							aks_blocked = check_for_aks_block(qtm_lib_key_group_ptr, num_sensor_keys);
							}            
							if(0u == aks_blocked)            
							{
							/* This key is not blocked from detection by AKS */
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_FILT_IN;
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = (uint16_t)qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_touch_di;
							reburst_required = 1u;
							}
						}
					}
				}
				break;
				case (QTM_KEY_STATE_FILT_IN):
				{
					if ((qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference) > (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals))
					{
						/* Signal < Reference -> Return to No Detect */
						qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
						qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = 0u;
					}
					else
					{
						touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals) - (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference);
						if (touch_delta > qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold)
						{
							if(0u == qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_aks_group)
							{
							/* This key not enabled for AKS (Grp = 0) */
							aks_blocked = 0u;
							}
							else
							{
							/* This key enabled for AKS, check for competing keys */
							aks_blocked = check_for_aks_block(qtm_lib_key_group_ptr, num_sensor_keys);
							}            
							if(0u == aks_blocked)            
							{
								if (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter > 0u)
								{
									/* Count into detect */
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter--;

									/* Reburst during Filter In */
									reburst_required = 1u;
								}
								else
								{
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_DETECT;

									keys_status_temp = QTM_KEY_DETECT;

									/* Reload MAX_ON_DURATION */
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_max_on_time;
								}
							}
						}
						else
						{
							/* (Sig - Ref) < Threshold -> Back to NO_DETECT */
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = 0u;
						}
					}
				}
				break;
				case (QTM_KEY_STATE_DETECT):
				{
					/* Status Flag */
					keys_status_temp = QTM_KEY_DETECT;

					/* Drift Hold */
					qtm_lib_key_group_ptr->qtm_touch_key_group_data->dht_count_in = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_drift_hold_time;

					if ((qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference) > (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals))
					{
						/* Signal < Reference -> Filter Out */
						qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_FILT_OUT;
						/* Reburst during Filter Out */
						reburst_required = 1u;
						qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = (uint16_t)qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_touch_di;
					}
					else
					{
						touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals) - (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference);

						/* Variable re-use node_cal_state & aks_blocked for threshold - hysteresis */
						aks_blocked = (qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold);

						/* Increment hysteresis to get bit-shift as setting of 0 should be 50% hysteresis */
						node_cal_state = (uint8_t)(aks_blocked >> ((qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_hysteresis) + 1u));
						aks_blocked -= node_cal_state;

						/* Check delta vs (Threshold - Hysteresis) */
						if (touch_delta > aks_blocked)
						{
							/* Still in detect */
						}
						else
						{
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_FILT_OUT;
							/* Reburst during Filter Out */
							reburst_required = 1u;
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = (uint16_t)qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_touch_di;
						}
					}
				}
				break;

				case (QTM_KEY_STATE_FILT_OUT):
				{
					/* Status Flag */
					keys_status_temp = QTM_KEY_DETECT;

					/* Count out of detect */
					if ((qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference) > (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals))
					{
						/* Signal < Reference -> Return to No Detect */
						if (0u == qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter)
						{
							/* Finished count-out -> go to no detect */
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
						}
						else
						{
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter--;
						}
					}
					else
					{
						touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals) - (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference);

						/* Variable re-use node_cal_state & aks_blocked for threshold - hysteresis */
						aks_blocked = (qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold);

						/* Increment hysteresis to get bit-shift as setting of 0 should be 50% hysteresis */
						node_cal_state = (uint8_t)(aks_blocked >> ((qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_hysteresis) + 1u));
						aks_blocked -= node_cal_state;

						/* Check delta vs (Threshold - Hysteresis) */
						if (touch_delta > aks_blocked)
						{
							/* Back to 'Detect' */
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_DETECT;

							/* Reload MAX_ON_DURATION */
							qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_max_on_time;
						}
						else
						{
							if (0u == qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter)
							{
								/* Finished count-out -> go to no detect */
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
							}
							else
							{
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter--;
								/* Reburst during Filter Out */
								reburst_required = 1u;
							}
							} /* /else */
							}     /* /else */
						}
						break;

						case (QTM_KEY_STATE_ANTI_TCH):
						{
							if ((qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference) > (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals))
							{
								touch_delta = (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference - qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals);
								if (touch_delta < (uint8_t)((qtm_lib_key_group_ptr->qtm_touch_key_config[num_sensor_keys].channel_threshold) >> qtm_lib_key_group_ptr->qtm_touch_key_group_config->sensor_anti_touch_recal_thr))
								{
									/* Delta is less than anti-touch threshold */
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = 0u;
								}
								/* Signal < Reference -> Still in anti-touch, count into recal */
								else if (qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter == 0u)
								{
									/* Recalibrate sensor node, then key */
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].channel_reference = qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].node_data_struct_ptr->node_acq_signals;
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
								}
								else
								{
									qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter--;
									/* Reburst during Anti-touch */
									reburst_required = 1u;
								}
							}
							else
							{
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state = QTM_KEY_STATE_NO_DET;
								qtm_lib_key_group_ptr->qtm_touch_key_data[num_sensor_keys].sensor_state_counter = 0u;
							}
						}
						break;
					default:
					{
				}
				break;
			} // switch
		}     // for loop

		if (0u == (qtm_lib_key_group_ptr->qtm_touch_key_group_data->qtm_keys_status & QTM_KEY_REBURST))
		{
			/* This was not a reburst */
		}
		else
		{
			/* This was a reburst - restore disabled (non reburst) nodes */
			qtm_lib_key_group_ptr->qtm_touch_key_group_data->qtm_keys_status &= (uint8_t)(~QTM_KEY_REBURST);
		}

		if (0u == reburst_required)
		{
		}
		else
		{
			qtm_lib_key_group_ptr->qtm_touch_key_group_data->qtm_keys_status |= QTM_KEY_REBURST;
		}

		if (0u == keys_status_temp)
		{
			/* No key in detect */
			qtm_lib_key_group_ptr->qtm_touch_key_group_data->qtm_keys_status &= (uint8_t) ~(QTM_KEY_DETECT);
		}
		else
		{
			/* Some key in detect */
			qtm_lib_key_group_ptr->qtm_touch_key_group_data->qtm_keys_status |= keys_status_temp;
		}

		qtm_timed_feature_process(qtm_lib_key_group_ptr);
	}

	return touch_return_thing;
}

/*============================================================================
uint8_t qtm_get_its_touch_keys_module_ver(void)
------------------------------------------------------------------------------
Purpose: Returns the module Firmware version
Input  : none
Output : Module ID - Upper nibble major / Lower nibble minor 
Notes  : none
============================================================================*/
uint8_t qtm_get_its_touch_keys_module_ver(void)
{
return QTM_MODULE_VERSION;
}
