/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

//V1,3 added 2 ITS sensors support.
//V1.2 changed pin to PA4 sensor pin, PA7 sample cap pin, (PA2 PA4 PA15 as ITS pin tested OK)
//PA 2 seems have less sensitivity than PA4 PA15
//V0.1 modified by ZELL to fit DIY ITS touch demo based on PA2 PA3(ADC) pins (not working))
//2025.3.12
//USART Printf support need to add harmony tool STDIO mpdule!

//PA19 pin28 CNANO LED0 
//PA27 pin39 CNANO SW0

/*
 * default sensor pin:
#define NODE_0_PARAMS {15u, 7u, GAIN_1} //ori
#define NODE_1_PARAMS {12u, 9u, GAIN_1}
 
 */


#include <stddef.h>                     // Defines NULL
#include <stdio.h> 
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "touch/touch.h"

//#define LED_A   (1u << 2u) //original

//#define LED_A   (1u << 19u)
//#define LED_B   (1u << 3u)

//#define NODE_0_PARAMS {4u, 7u, GAIN_1}   //
//#define NODE_1_PARAMS {15u, 6u, GAIN_1}  //

extern volatile uint8_t measurement_done_touch;

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
//CLRWDT(): 
// *****************************************************************************
// *****************************************************************************
uint32_t sys_cnt = 0;
void TC2_INT_callback(TC_TIMER_STATUS status, uintptr_t context);

int main(void) {

    /* Initialize all modules */
    SYS_Initialize(NULL);

    touch_init();

    SYSTICK_TimerStart();
    //uintptr_t TC2_context=5;
    //TC2_TimerCallbackRegister(TC2_INT_callback,TC2_context);
    TC2_TimerCallbackRegister(TC2_INT_callback, (uintptr_t) NULL);

    printf("< PIC32CM JH Curiosity Nano ITS touch test demo>\r\n");
    printf("-Version 1.3, 27.Mar.2025 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("--FW code compiled with XC32 Version: %d\n", __XC32_VERSION__);
    printf(" ITS touch loop starts now...\r\n");
    //printf("--Platform has DSP engine: %d\n", __HAS_DSP__ );
    TC2_TimerStart();
    WDT_Enable();


    while (true) {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks();

        touch_process();

        if (measurement_done_touch == 1u) {
            measurement_done_touch = 0u;

            if ((get_sensor_state(0) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT) {
                //PORT_REGS->GROUP[0].PORT_OUTSET = LED_B;
                GPIO_PA19_LED0_Set();
            } else {
                //PORT_REGS->GROUP[0].PORT_OUTCLR = LED_B;
                GPIO_PA19_LED0_Clear();
            }
            if (2 == DEF_NUM_CHANNELS) {
                if ((get_sensor_state(1) & QTM_KEY_STATE_DETECT) == QTM_KEY_STATE_DETECT) {
                    //PORT_REGS->GROUP[0].PORT_OUTSET = LED_A;
                    GPIO_PA19_LED0_Set();
                } else {
                    //PORT_REGS->GROUP[0].PORT_OUTCLR = LED_A;
                    GPIO_PA19_LED0_Clear();
                }
            }
        }
#if DEF_TOUCH_LOWPOWER_ENABLE == 1
        PM_StandbyModeEnter();
#endif
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE);
}


//not working~!

void TC2_INT_callback(TC_TIMER_STATUS status, uintptr_t context) {

    sys_cnt++;
    WDT_Clear();
    GPIO_PA19_LED0_Toggle();
    //TC_TIMER_STATUS res =0;
    //return res;
    //return 1;
}

/*******************************************************************************
 End of File
 */

